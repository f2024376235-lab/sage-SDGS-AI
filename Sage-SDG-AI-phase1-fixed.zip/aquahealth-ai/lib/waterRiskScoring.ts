import { waterDataset, type RiskLevel } from "../data/waterDataset";
import type { AgentRequest } from "./sdgAgent";

const seriousSymptoms = [
  "diarrhea",
  "vomiting",
  "fever",
  "dehydration",
  "child",
  "children",
  "blood",
  "sewage",
  "multiple people sick"
];

const mediumKeywords = ["cloudy", "salty", "particles", "taste", "sediment", "mild"];
const highKeywords = ["bad smell", "smell", "yellow", "brown", "dirty", "rust", "stomach pain", "skin irritation", "many people"];

function normalize(value = "") {
  return value.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}

function containsAny(text: string, words: string[]) {
  return words.some((word) => text.includes(word));
}

function priorityFromRisk(level: RiskLevel) {
  const map: Record<RiskLevel, "Normal" | "Priority" | "Urgent" | "Critical"> = {
    Low: "Normal",
    Medium: "Priority",
    High: "Urgent",
    Emergency: "Critical"
  };
  return map[level];
}

function calculateRisk(req: AgentRequest, matchedRisk: RiskLevel): RiskLevel {
  const text = normalize(`${req.category ?? ""} ${req.message ?? ""} ${req.symptoms ?? ""} ${req.urgency ?? ""}`);
  const peopleAffected = Number(req.peopleAffected ?? 0);

  if (containsAny(text, seriousSymptoms) || peopleAffected >= 8 || text.includes("emergency")) return "Emergency";
  if (containsAny(text, highKeywords) || peopleAffected >= 3 || text.includes("high")) return "High";
  if (containsAny(text, mediumKeywords) || text.includes("medium")) return "Medium";
  return matchedRisk;
}

function findBestRecord(req: AgentRequest) {
  const text = normalize(`${req.category ?? ""} ${req.message ?? ""} ${req.symptoms ?? ""}`);

  return waterDataset.find((record) => {
    const category = normalize(record.water_issue_category);
    const symptoms = record.common_symptoms.split(",").map((item) => normalize(item));

    return (
      text.includes(category) ||
      category.split(" ").some((term) => term.length > 3 && text.includes(term)) ||
      symptoms.some((symptom) => symptom.length > 3 && text.includes(symptom))
    );
  }) ?? waterDataset[0];
}

export function handleWaterQuery(req: AgentRequest) {
  let matchedRecord = findBestRecord(req);
  const calculatedRisk = calculateRisk(req, matchedRecord.risk_level);

  if (calculatedRisk === "Emergency") {
    matchedRecord = waterDataset.find((record) => record.risk_level === "Emergency") ?? matchedRecord;
  }

  const priority = priorityFromRisk(calculatedRisk);
  const locationText = req.location ? ` Location: ${req.location}.` : "";
  const symptomText = req.symptoms ? ` Reported symptoms: ${req.symptoms}.` : "";

  return {
    issue_summary: `${matchedRecord.water_issue_category}.${locationText}${symptomText}`.trim(),
    possible_cause: matchedRecord.possible_cause,
    risk_level: calculatedRisk,
    immediate_safety_steps: [
      matchedRecord.recommended_action,
      "Use boiled, filtered, or verified safe water for drinking and food preparation until the issue is resolved.",
      "Keep safe water in a clean, covered container and avoid mixing it with suspected water.",
      calculatedRisk === "Emergency"
        ? "Seek medical help immediately if severe diarrhea, vomiting, fever, dehydration, blood in stool, or illness in children is present."
        : "Monitor symptoms and contact a qualified doctor or local health center if symptoms continue or worsen."
    ],
    health_risk_awareness: matchedRecord.related_health_risk,
    complaint_report_suggestion: `Complaint priority: ${priority}. Report the location, water color/smell/taste, number of people affected, symptoms, and photos if available.`,
    disclaimer: "AquaLife provides general water-safety and health-risk awareness only. It does not diagnose disease or prescribe treatment. For serious symptoms or vulnerable people such as children, elderly people, or pregnant people, contact a qualified doctor or emergency service immediately."
  };
}
