import { handleEducationQuery } from "./educationLogic";
import { handleWellbeingQuery } from "./wellbeingLogic";
import { handleWaterQuery } from "./waterRiskScoring";

export type AgentMode = "education" | "wellbeing" | "water";

export type AgentRequest = {
  mode: AgentMode;
  message: string;
  category?: string;
  symptoms?: string;
  location?: string;
  peopleAffected?: number;
  urgency?: string;
};

export async function processAgentRequest(req: AgentRequest) {
  switch (req.mode) {
    case "education":
      return handleEducationQuery(req.message);
    case "wellbeing":
      return handleWellbeingQuery(req.message);
    case "water":
      return handleWaterQuery(req);
    default:
      throw new Error("Unknown mode. Please choose Learn, MindCare, or AquaLife.");
  }
}
