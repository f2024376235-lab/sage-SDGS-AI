import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        sage: {
          50: "#f4fbf7",
          100: "#def5e8",
          200: "#bfead3",
          300: "#8ddbb5",
          400: "#57c48f",
          500: "#2fae73",
          600: "#218b5b",
          700: "#1d704b",
          800: "#1b5a3f",
          900: "#174a35"
        },
        aqua: {
          50: "#ecfeff",
          100: "#cffafe",
          500: "#06b6d4",
          700: "#0e7490"
        }
      },
      boxShadow: {
        glow: "0 18px 60px rgba(15, 118, 110, 0.18)"
      }
    }
  },
  plugins: []
};
export default config;
