import { KnowledgeItem, modeLabels, SageMode, sdgDashboard } from "./knowledge";
import { ChatMessage, retrieveKnowledge, summarizeHistory } from "./vectorMemory";
import { buildMindCareConversation, detectMindCareSignals, mindCareSystemInstructions } from "./mindEaseKnowledge";

export type AgentRequest = {
  message: string;
  mode: SageMode;
  history?: ChatMessage[];
};

export type AgentResponse = {
  answer: string;
  sources: string[];
  mode: SageMode;
  dashboardSpeech: string;
};

function bulletList(items: string[], max = 4): string {
  return items.slice(0, max).map((item) => `- ${item}`).join("\n");
}

function buildLocalAnswer(message: string, mode: SageMode, context: KnowledgeItem[], history: ChatMessage[] = []): string {
  const main = context[0];
  const modeName = modeLabels[mode];
  const userAskedForProject = /project|idea|proposal|dashboard|dataset|model|agent|app/i.test(message);
  const asksForBasics = /basic|simple|explain|what is|water cycle|beginner/i.test(message);
  const historyNote = summarizeHistory(history);

  if (mode === "mindcare") {
    return buildMindCareConversation(message, historyNote);
  }

  const sections = [
    `### ${modeName}: ${main.title}`,
    main.summary,
    `### Why this happens\n${bulletList(main.causes)}`,
    `### Why it matters\n${bulletList(main.impacts)}`,
    `### Practical actions\n${bulletList(main.actions)}`
  ];

  if (main.countryExample) {
    sections.push(`### Local example\n${main.countryExample}`);
  }

  if (main.metric) {
    sections.push(`### Quick data point\n**${main.metric.label}: ${main.metric.value}** — ${main.metric.meaning}`);
  }

  if (mode === "aqualife" && asksForBasics) {
    sections.push(
      "### Simple teaching angle\nThink of water like a moving system, not a fixed object. Rain, drains, rivers, pipes, tanks, groundwater, farms, and homes are connected. So one dirty drain near a water point can become a health problem for a whole street."
    );
  }

  if (userAskedForProject) {
    sections.push(
      "### Project upgrade idea\nAdd a small local dataset table with columns: location, SDG issue, cause, affected group, severity, current action, and suggested solution. Then let Sage SDGs AI retrieve the closest cases before answering. That makes the agent feel trained instead of random."
    );
  }

  if (history.length > 0) {
    sections.push(`### Conversation continuity\nI used your recent chat context to keep the response aligned. Latest context summary: ${historyNote.split("\n").slice(-2).join(" | ")}`);
  }

  return sections.join("\n\n");
}

function buildSystemPrompt(mode: SageMode, context: KnowledgeItem[], history: ChatMessage[] = []): string {
  return `You are Sage SDGs AI, a practical SDG assistant. Current mode: ${modeLabels[mode]}.

Behavior rules:
- Answer like a trained SDG advisor, not a generic chatbot.
- Use clear headings: answer, causes, impacts, practical actions, local example.
- Be practical for students, communities, NGOs, and local government.
- For MindCare, be supportive, conversational, and safe. Do not diagnose. Escalate crisis/self-harm risk.
- For AquaLife, focus on clean water, pollution, sanitation, floods, and health.
- Keep the tone clear, direct, educational, and interactive.
- Ask useful follow-up questions when the user needs guidance.

Retrieved knowledge:
${context.map((item) => `Title: ${item.title}\nSummary: ${item.summary}\nCauses: ${item.causes.join("; ")}\nImpacts: ${item.impacts.join("; ")}\nActions: ${item.actions.join("; ")}\nExample: ${item.countryExample ?? "N/A"}`).join("\n\n")}

MindCare extra instructions:
${mindCareSystemInstructions()}

Recent conversation:
${summarizeHistory(history)}`;
}

async function tryGroqAnswer(message: string, mode: SageMode, context: KnowledgeItem[], history: ChatMessage[] = []): Promise<string | null> {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) return null;

  try {
    const model = process.env.GROQ_MODEL || "llama-3.1-8b-instant";
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model,
        temperature: 0.35,
        messages: [
          { role: "system", content: buildSystemPrompt(mode, context, history) },
          { role: "user", content: message }
        ]
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    return data?.choices?.[0]?.message?.content ?? null;
  } catch {
    return null;
  }
}

export function getDashboardSpeech(): string {
  const scores = sdgDashboard
    .map((item) => `${item.label}, ${item.title}, score ${item.score} out of 100. ${item.note}`)
    .join(" ");
  return `Sage SDGs AI dashboard summary. ${scores} Highest current focus is ${sdgDashboard[0].label} health and well-being, while climate and water need stronger local action.`;
}

export async function respondWithSage({ message, mode, history = [] }: AgentRequest): Promise<AgentResponse> {
  const context = retrieveKnowledge(message, mode, 3);
  const assessment = mode === "mindcare" ? detectMindCareSignals(message) : null;
  const groqAnswer = await tryGroqAnswer(message, mode, context, history);
  const answer =
    mode === "mindcare" && assessment?.riskLevel === "crisis"
      ? buildLocalAnswer(message, mode, context, history)
      : groqAnswer || buildLocalAnswer(message, mode, context, history);

  return {
    answer,
    sources: context.map((item) => item.title),
    mode,
    dashboardSpeech: getDashboardSpeech()
  };
}
