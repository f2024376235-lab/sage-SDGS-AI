export type MindCareRiskLevel = "low" | "medium" | "high" | "crisis";

export type MindCareSignal = {
  id: string;
  label: string;
  tags: string[];
  likelyFeelings: string[];
  commonDrivers: string[];
  supportSteps: string[];
  followUps: string[];
  sdgConnection: string;
};

export type MindCareAssessment = {
  riskLevel: MindCareRiskLevel;
  detectedSignals: MindCareSignal[];
  crisisTerms: string[];
  tone: "calm" | "urgent" | "coaching";
};

const crisisPatterns = [
  /\bsuicide\b/i,
  /\bkill myself\b/i,
  /\bend my life\b/i,
  /\bwant to die\b/i,
  /\bi want to die\b/i,
  /\bcan't live\b/i,
  /\bcant live\b/i,
  /\bself harm\b/i,
  /\bharm myself\b/i,
  /\bcut myself\b/i,
  /\bno reason to live\b/i,
  /\bunsafe\b/i
];

const highRiskPatterns = [
  /\bpanic attack\b/i,
  /\bviolence\b/i,
  /\babuse\b/i,
  /\bthreat\b/i,
  /\boverdose\b/i,
  /\bnot safe\b/i,
  /\blose control\b/i,
  /\bhearing voices\b/i,
  /\bcan't control\b/i,
  /\bcant control\b/i
];

export const mindCareSignals: MindCareSignal[] = [
  {
    id: "academic-pressure",
    label: "Academic pressure and exam stress",
    tags: ["study", "exam", "paper", "assignment", "deadline", "marks", "presentation", "university", "school", "students"],
    likelyFeelings: ["overloaded", "afraid of failure", "mentally tired", "unable to start"],
    commonDrivers: [
      "Too many tasks are competing for attention at the same time.",
      "The brain treats the whole semester as one huge threat instead of one next task.",
      "Poor sleep and guilt-loop scrolling make the workload feel heavier."
    ],
    supportSteps: [
      "Write every pending task on paper, then circle only the next 25-minute task.",
      "Use a 25-5 cycle: study for 25 minutes, breathe/walk for 5 minutes, repeat twice.",
      "Reduce the target from perfect to submitted, then improve the highest-mark sections first.",
      "Send one message to a classmate/teacher if you are stuck instead of silently panicking."
    ],
    followUps: [
      "What is the nearest deadline: exam, assignment, viva, or presentation?",
      "Which part is blocking you most right now: starting, understanding, memorizing, or confidence?"
    ],
    sdgConnection: "SDG 3 and SDG 4 connect here: mental well-being directly affects learning, attendance, confidence, and academic performance."
  },
  {
    id: "anxiety-overthinking",
    label: "Anxiety and overthinking",
    tags: ["anxiety", "overthinking", "worry", "fear", "panic", "tension", "nervous", "restless", "heart", "breathing"],
    likelyFeelings: ["unsafe without clear danger", "stuck in repeated thoughts", "body tension", "loss of control"],
    commonDrivers: [
      "The threat system is active, so the mind keeps scanning for problems.",
      "Uncertainty becomes harder to tolerate when the body is tired or overstimulated.",
      "Avoiding the task gives short relief but makes the fear return stronger."
    ],
    supportSteps: [
      "Do 4-6 breathing: inhale for 4 seconds, exhale for 6 seconds, repeat 8 times.",
      "Name the worry, then separate facts from predictions in two columns.",
      "Choose one small action that gives evidence of control, even if the feeling remains.",
      "Avoid checking/rechecking the same thing repeatedly because it trains the fear loop."
    ],
    followUps: [
      "Is your anxiety mostly in your body, your thoughts, or both?",
      "What situation triggered it today?"
    ],
    sdgConnection: "SDG 3 includes mental and emotional well-being, not only physical illness."
  },
  {
    id: "sadness-low-mood",
    label: "Low mood, sadness, and loss of motivation",
    tags: ["sad", "depressed", "low", "empty", "cry", "motivation", "hopeless", "tired", "alone", "lonely"],
    likelyFeelings: ["heavy", "disconnected", "unmotivated", "hopeless or numb"],
    commonDrivers: [
      "Low mood often reduces energy first, then the person blames themselves for not doing enough.",
      "Isolation removes feedback that could challenge hopeless thoughts.",
      "Sleep, food, movement, sunlight, and human contact strongly affect mood regulation."
    ],
    supportSteps: [
      "Do one body-first action: drink water, wash face, sit in sunlight, or walk for 7 minutes.",
      "Send a simple message to one safe person: ‘I am not feeling okay today. Can you talk?’",
      "Pick a tiny non-negotiable task, not a huge life plan.",
      "If this continues for days or affects daily functioning, speak with a qualified professional."
    ],
    followUps: [
      "How long have you been feeling this way: today, this week, or longer?",
      "Are you still able to sleep, eat, study/work, and talk to people normally?"
    ],
    sdgConnection: "Better mental well-being improves participation in education, work, family life, and community health."
  },
  {
    id: "sleep-burnout",
    label: "Sleep problems and burnout",
    tags: ["sleep", "insomnia", "burnout", "exhausted", "fatigue", "screen", "phone", "late night", "tired"],
    likelyFeelings: ["drained", "irritable", "foggy", "unable to focus"],
    commonDrivers: [
      "Late-night screen use and stress keep the brain alert when it should downshift.",
      "Burnout comes from long effort without recovery, control, or visible progress.",
      "Caffeine, irregular sleep timing, and pressure loops worsen the cycle."
    ],
    supportSteps: [
      "Set one fixed wake-up time for the next 3 days; this stabilizes the sleep rhythm faster than forcing sleep.",
      "Stop heavy studying or stressful scrolling 30 minutes before bed; use a boring wind-down routine.",
      "Move unfinished tasks into a ‘tomorrow list’ so the brain stops rehearsing them.",
      "If sleep loss is severe or long-running, get professional advice."
    ],
    followUps: [
      "How many hours did you sleep last night?",
      "Is the problem falling asleep, waking up, or waking tired?"
    ],
    sdgConnection: "Sleep and recovery are health foundations under SDG 3 because they affect focus, safety, learning, and emotional control."
  },
  {
    id: "water-climate-distress",
    label: "Stress from water, climate, or community problems",
    tags: ["water", "pollution", "flood", "heat", "climate", "disease", "community", "family", "financial", "environment"],
    likelyFeelings: ["worried for family", "helpless", "angry", "unsafe", "responsible for too much"],
    commonDrivers: [
      "Environmental stress creates real-life pressure, not only emotional discomfort.",
      "When basic needs like clean water or safety feel uncertain, the nervous system stays on alert.",
      "Communities often need practical support plus emotional reassurance together."
    ],
    supportSteps: [
      "Separate the problem into immediate safety, health prevention, and long-term solution.",
      "For water concerns, prioritize safe drinking water, hygiene, and reporting contamination hotspots.",
      "Talk to one trusted person or local group so the burden is not carried alone.",
      "Use Sage AquaLife mode for a community action plan after your immediate stress is calmer."
    ],
    followUps: [
      "Is this about your own stress, your family, or a community issue?",
      "Is there an immediate safety or health risk right now?"
    ],
    sdgConnection: "This is where SDG 3, SDG 6, SDG 11, and SDG 13 overlap: health, water, safe cities, and climate resilience."
  },
  {
    id: "general-support",
    label: "General emotional support",
    tags: ["help", "support", "feel", "mental", "mind", "care", "wellbeing", "well-being", "stress"],
    likelyFeelings: ["unclear but uncomfortable", "needing someone to listen", "seeking direction"],
    commonDrivers: [
      "Sometimes the user does not need a lecture first; they need the problem reflected clearly.",
      "Naming the feeling can reduce confusion and help choose the next step.",
      "Small action plus human connection works better than motivational quotes alone."
    ],
    supportSteps: [
      "Tell Sage what happened, what you felt, and what you need help deciding.",
      "Use the check-in formula: feeling, trigger, intensity from 1 to 10, and one safe next action.",
      "Choose a grounding exercise if the feeling is intense before solving the problem.",
      "Reach out to a trusted person or professional if the problem feels bigger than self-help."
    ],
    followUps: [
      "What happened today that made you feel this way?",
      "On a scale of 1 to 10, how intense is it right now?"
    ],
    sdgConnection: "Mental well-being support helps people stay connected to education, work, family, and community life."
  }
];

function cleanText(text: string): string {
  return text.toLowerCase().replace(/[^a-z0-9\s-]/g, " ");
}

export function detectMindCareSignals(message: string): MindCareAssessment {
  const clean = cleanText(message);
  const crisisTerms = crisisPatterns.filter((pattern) => pattern.test(message)).map((pattern) => pattern.source);
  const highRisk = highRiskPatterns.some((pattern) => pattern.test(message));

  const detected = mindCareSignals
    .map((signal) => {
      const score = signal.tags.reduce((total, tag) => {
        const normalized = tag.toLowerCase();
        return clean.includes(normalized) ? total + (normalized.length > 5 ? 3 : 2) : total;
      }, 0);
      return { signal, score };
    })
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((entry) => entry.signal);

  const detectedSignals = detected.length > 0 ? detected.slice(0, 2) : [mindCareSignals.find((signal) => signal.id === "general-support")!];

  if (crisisTerms.length > 0) {
    return { riskLevel: "crisis", detectedSignals, crisisTerms, tone: "urgent" };
  }
  if (highRisk) {
    return { riskLevel: "high", detectedSignals, crisisTerms, tone: "urgent" };
  }
  if (/\bvery\b|\btoo much\b|\boverwhelmed\b|\bcan't handle\b|\bcant handle\b|\bpanic\b/i.test(message)) {
    return { riskLevel: "medium", detectedSignals, crisisTerms, tone: "calm" };
  }
  return { riskLevel: "low", detectedSignals, crisisTerms, tone: "coaching" };
}

export function buildCrisisResponse(): string {
  return [
    "I’m really glad you said this instead of keeping it inside. This sounds serious, so we need to put safety first right now.",
    "Please contact emergency services in your area, a crisis helpline, a mental-health professional, or a trusted person who can stay with you. Do not stay alone if you might hurt yourself or someone else.",
    "Right now, move away from anything you could use to harm yourself, sit somewhere visible/safe, and send this message to one trusted person: ‘I am not safe alone right now. Please call me or come to me.’",
    "For the next 60 seconds: put both feet on the floor, breathe out slowly, name 5 things you see, 4 things you feel, 3 things you hear, 2 things you smell, and 1 thing you can taste.",
    "I can stay with you for grounding and planning, but I cannot replace emergency or professional help. Your next move should be human support now."
  ].join("\n\n");
}

export function buildHighRiskResponse(signal: MindCareSignal): string {
  return [
    `I hear you. This may be more than normal stress, especially if there is panic, abuse, violence, loss of control, or feeling unsafe. Let’s slow it down and handle safety first.`,
    `**First check:** Are you physically safe right now? If there is immediate danger, contact local emergency services or a trusted person nearby before continuing the chat.`,
    `**What might be happening:** ${signal.commonDrivers[0]} ${signal.commonDrivers[1]}`,
    `**Next 3 steps:**\n- ${signal.supportSteps.slice(0, 3).join("\n- ")}`,
    `**One question so I can guide you better:** ${signal.followUps[0]}`,
    `Safety note: I can support you with grounding and next-step planning, but this is not diagnosis, therapy, or emergency care.`
  ].join("\n\n");
}

export function buildMindCareConversation(message: string, historySummary: string): string {
  const assessment = detectMindCareSignals(message);
  const signal = assessment.detectedSignals[0];

  if (assessment.riskLevel === "crisis") return buildCrisisResponse();
  if (assessment.riskLevel === "high") return buildHighRiskResponse(signal);

  const intensityLine = assessment.riskLevel === "medium"
    ? "This sounds heavy, so don’t try to solve your whole life in one sitting. We’ll reduce the emotional pressure first, then choose one next action."
    : "Let’s handle it practically: first understand the feeling, then reduce the load, then choose one small step.";

  const secondSignal = assessment.detectedSignals[1];
  const combinedNote = secondSignal
    ? `I’m also noticing a possible second layer: **${secondSignal.label}**. That matters because two pressures at once can make a normal problem feel impossible.`
    : "I don’t want to over-assume, so I’ll keep this grounded in what you said.";

  return [
    `I hear you. From your message, this looks like **${signal.label}**. You are not weak for feeling this; the real issue is that your mind is trying to process pressure without enough structure or support.`,
    intensityLine,
    combinedNote,
    `**What may be driving it**\n- ${signal.commonDrivers.join("\n- ")}`,
    `**Do this now, not later**\n- ${signal.supportSteps.slice(0, 4).join("\n- ")}`,
    `**Tiny check-in**\nAnswer these two things and I’ll guide the next reply like a real assistant, not a lecture:\n1. ${signal.followUps[0]}\n2. ${signal.followUps[1]}`,
    `**SDG connection**\n${signal.sdgConnection}`,
    `**Safe boundary**\nThis is general mental well-being support, not a diagnosis or therapy. If this feeling is severe, persistent, or unsafe, involve a qualified professional or trusted person.`,
    historySummary && historySummary !== "No previous chat context." ? `**Continuity**\nI also used your recent chat context so the answer does not restart from zero.` : ""
  ].filter(Boolean).join("\n\n");
}

export function mindCareSystemInstructions(): string {
  return `MindCare conversation style:
- Reply like a calm Copilot-style support assistant: empathetic, practical, and interactive.
- Start by reflecting the user's likely emotional state without overclaiming or diagnosing.
- Ask one or two useful follow-up questions at the end.
- Give tiny next actions, not generic motivation.
- Separate crisis/high-risk support from normal stress support.
- Never claim to be a therapist or doctor.
- Never diagnose depression, anxiety disorder, PTSD, ADHD, or any medical condition.
- Encourage human/professional support when risk is high, symptoms persist, or functioning is impaired.
- For self-harm, suicide, violence, or immediate danger, prioritize emergency/human support immediately.`;
}
