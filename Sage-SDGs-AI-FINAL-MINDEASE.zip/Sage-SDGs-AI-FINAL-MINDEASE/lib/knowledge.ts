export type SageMode = "learn" | "mindcare" | "aqualife";

export type KnowledgeItem = {
  id: string;
  mode: SageMode | "all";
  title: string;
  tags: string[];
  summary: string;
  causes: string[];
  impacts: string[];
  actions: string[];
  countryExample?: string;
  metric?: {
    label: string;
    value: string;
    meaning: string;
  };
};

export const sdgDashboard = [
  {
    label: "SDG 3",
    title: "Good Health & Well-being",
    score: 72,
    note: "Focus area: mental well-being, prevention, access to support."
  },
  {
    label: "SDG 6",
    title: "Clean Water & Sanitation",
    score: 64,
    note: "Focus area: safe drinking water, pollution control, hygiene."
  },
  {
    label: "SDG 13",
    title: "Climate Action",
    score: 58,
    note: "Focus area: heat stress, flooding, climate-water-health links."
  },
  {
    label: "SDG 11",
    title: "Sustainable Cities",
    score: 61,
    note: "Focus area: waste systems, safe public spaces, resilience."
  }
];

export const knowledgeBase: KnowledgeItem[] = [
  {
    id: "sdg-basics",
    mode: "learn",
    title: "What SDGs are and why they matter",
    tags: ["sdg", "sustainable development", "poverty", "education", "health", "water", "climate", "basics"],
    summary:
      "The Sustainable Development Goals are 17 global goals for improving human life while protecting the planet. They connect poverty, education, health, clean water, climate, gender, energy, work, and institutions instead of treating them as separate problems.",
    causes: [
      "Development problems are connected, so weak water systems can damage health and education at the same time.",
      "Short-term planning often ignores environmental cost, social inequality, and future risk.",
      "Poor data makes governments and communities react late instead of preventing problems early."
    ],
    impacts: [
      "SDGs help convert broad problems into measurable targets.",
      "They guide NGOs, schools, businesses, and governments toward shared priorities.",
      "They make social impact easier to explain, fund, and track."
    ],
    actions: [
      "Pick one SDG problem, one affected group, and one measurable outcome.",
      "Collect small but reliable local data before proposing solutions.",
      "Design solutions that are practical, affordable, and culturally realistic."
    ],
    countryExample:
      "For Pakistan, SDG planning becomes stronger when clean water, school health, flood resilience, and local government data are connected instead of handled separately.",
    metric: {
      label: "Goal count",
      value: "17 SDGs",
      meaning: "A complete framework for social, economic, and environmental progress."
    }
  },
  {
    id: "water-pollution",
    mode: "aqualife",
    title: "Water pollution and community health",
    tags: ["water", "pollution", "contamination", "drinking water", "sanitation", "industrial waste", "sewage", "sdg 6"],
    summary:
      "Water pollution happens when sewage, industrial discharge, agricultural runoff, plastics, chemicals, or unsafe storage contaminate water sources. The problem is not only environmental; it becomes a health, education, income, and dignity issue.",
    causes: [
      "Untreated sewage entering rivers, canals, ponds, or groundwater.",
      "Industrial wastewater released without proper treatment.",
      "Fertilizers, pesticides, and animal waste washing into water sources.",
      "Damaged pipes, open storage containers, and poor household hygiene."
    ],
    impacts: [
      "Diarrheal diseases, skin infections, and higher child health risks.",
      "School absence because children spend time collecting water or become sick.",
      "Higher medical spending for poor households.",
      "Lower trust in local services and government response."
    ],
    actions: [
      "Test water regularly for visible smell/color plus basic microbial and chemical indicators.",
      "Separate drinking-water sources from drains, animals, and waste dumping points.",
      "Use household treatment like boiling, chlorination, or certified filtration when source safety is uncertain.",
      "Report industrial discharge and build local monitoring dashboards for hotspots."
    ],
    countryExample:
      "In a Pakistani rural or peri-urban context, the strongest low-cost start is mapping water points, nearby drains, waste sites, disease complaints, and household treatment habits.",
    metric: {
      label: "SDG link",
      value: "SDG 6",
      meaning: "Clean water and sanitation directly affects health, education, poverty, and climate resilience."
    }
  },
  {
    id: "water-cycle-basics",
    mode: "aqualife",
    title: "Water cycle basics for SDG learning",
    tags: ["water cycle", "evaporation", "condensation", "precipitation", "groundwater", "floods", "climate"],
    summary:
      "The water cycle moves water through evaporation, condensation, precipitation, runoff, infiltration, and groundwater flow. SDG work uses this cycle to understand floods, drought, pollution movement, and water availability.",
    causes: [
      "Heat turns surface water into vapor through evaporation.",
      "Water vapor cools and forms clouds through condensation.",
      "Rain, snow, or hail returns water to land through precipitation.",
      "Water either runs across land, enters soil, or recharges groundwater."
    ],
    impacts: [
      "Deforestation and concrete surfaces increase runoff and flood risk.",
      "Pollution on land can enter rivers or groundwater during rainfall.",
      "Climate change can intensify heavy rainfall and dry periods."
    ],
    actions: [
      "Protect green spaces and wetlands because they slow runoff.",
      "Keep waste away from drains and water bodies before rainfall.",
      "Use rainwater harvesting where local quality and storage conditions are safe.",
      "Teach students with local examples: clouds, canals, drains, wells, and flood streets."
    ],
    countryExample:
      "In flood-prone areas, water-cycle education should connect rainfall, blocked drains, encroachment, waste dumping, and disease risk.",
    metric: {
      label: "Core process",
      value: "6 stages",
      meaning: "Evaporation, condensation, precipitation, runoff, infiltration, and groundwater flow."
    }
  },
  {
    id: "mental-wellbeing",
    mode: "mindcare",
    title: "Mental well-being and SDG 3",
    tags: ["mental health", "wellbeing", "stress", "students", "workplace", "anxiety", "sdg 3", "mindcare"],
    summary:
      "Mental well-being is part of SDG 3 because health is not only the absence of disease. Stress, isolation, fear, financial pressure, and unsafe environments can reduce learning, work quality, and community participation.",
    causes: [
      "Academic, job, family, or financial pressure without proper support.",
      "Poor sleep, excessive screen time, social comparison, and isolation.",
      "Unsafe neighborhoods, disasters, water insecurity, or disease outbreaks.",
      "Stigma that stops people from asking for help early."
    ],
    impacts: [
      "Lower focus, motivation, and decision quality.",
      "Higher conflict in homes, schools, and workplaces.",
      "Physical symptoms like fatigue, headaches, and sleep disturbance.",
      "Risk of crisis when warning signs are ignored."
    ],
    actions: [
      "Start with a small routine: sleep window, hydration, sunlight, movement, and one trusted conversation.",
      "Use breathing or grounding exercises during stress spikes.",
      "Reduce overload by writing the next one practical step instead of solving everything at once.",
      "Seek professional or emergency help if there is self-harm risk, violence risk, or loss of control."
    ],
    countryExample:
      "For students, workers, and flood-affected communities, mental well-being support should be practical, stigma-free, and connected to local services.",
    metric: {
      label: "SDG link",
      value: "SDG 3",
      meaning: "Good health includes mental, emotional, and social well-being."
    }
  },
  {
    id: "mindease-academic-stress",
    mode: "mindcare",
    title: "MindCare: academic pressure conversation pattern",
    tags: ["study", "exam", "assignment", "deadline", "paper", "presentation", "viva", "students", "academic stress"],
    summary:
      "Academic stress becomes harder when tasks are vague, deadlines are close, sleep is poor, and the student treats the whole workload as one giant threat. Sage should respond with empathy, task reduction, and one small next step.",
    causes: [
      "Too many tasks are being processed at once.",
      "Fear of failure makes starting harder.",
      "Sleep loss and scrolling reduce attention control.",
      "The student may need structure more than motivation."
    ],
    impacts: [
      "Lower concentration and memory.",
      "Avoidance, procrastination, and guilt loops.",
      "Physical tension, irritability, and panic-like feelings.",
      "Reduced confidence before exams or presentations."
    ],
    actions: [
      "Ask for the nearest deadline and the exact blocked task.",
      "Turn the work into a 25-minute first action.",
      "Prioritize high-mark sections before polishing.",
      "Suggest asking a classmate or teacher when stuck."
    ],
    countryExample:
      "For university students, the agent should guide with short practical steps: list tasks, choose the nearest deadline, study in short cycles, and ask one human for help if blocked.",
    metric: {
      label: "Support style",
      value: "Reflect → Reduce → Act",
      meaning: "First reflect the feeling, then reduce the task load, then give one action."
    }
  },
  {
    id: "mindease-anxiety-grounding",
    mode: "mindcare",
    title: "MindCare: anxiety and grounding support",
    tags: ["anxiety", "overthinking", "panic", "worry", "fear", "nervous", "breathing", "grounding"],
    summary:
      "When the user shows anxiety or overthinking, Sage should calm the body first, separate facts from predictions, and avoid giving huge advice before the nervous system settles.",
    causes: [
      "The brain may be scanning for danger even when the danger is uncertain.",
      "Repeated checking can strengthen the worry loop.",
      "Caffeine, lack of sleep, and uncertainty can intensify body symptoms.",
      "Avoidance gives short-term relief but increases long-term fear."
    ],
    impacts: [
      "Fast thoughts, racing heart, tight chest, and poor focus.",
      "Decision paralysis and repeated reassurance seeking.",
      "Sleep disruption and irritability.",
      "Avoidance of study, work, or social situations."
    ],
    actions: [
      "Use 4-6 breathing for one minute.",
      "Write facts in one column and predictions in another.",
      "Pick one action that gives evidence of control.",
      "Ask whether anxiety is mainly body-based, thought-based, or both."
    ],
    countryExample:
      "In a student or workplace context, anxiety support should be short, calming, and action-based instead of long motivational lectures.",
    metric: {
      label: "Grounding time",
      value: "60 seconds",
      meaning: "A short body reset can make the next decision easier."
    }
  },
  {
    id: "mindease-sleep-burnout",
    mode: "mindcare",
    title: "MindCare: sleep and burnout recovery",
    tags: ["sleep", "insomnia", "burnout", "fatigue", "tired", "screen", "phone", "late night", "exhausted"],
    summary:
      "Sleep and burnout issues should be handled with rhythm, recovery, and reduced cognitive load. Sage should avoid shaming the user and focus on a simple 3-day reset.",
    causes: [
      "Irregular sleep timing confuses the body clock.",
      "Stress and unfinished tasks keep the mind rehearsing problems.",
      "Heavy screen use before bed increases alertness.",
      "Long effort without recovery leads to burnout."
    ],
    impacts: [
      "Poor memory and focus.",
      "More emotional reactions and lower patience.",
      "Reduced productivity despite spending more hours working.",
      "Higher risk of long-term stress problems if ignored."
    ],
    actions: [
      "Keep one fixed wake-up time for three days.",
      "Move unfinished tasks into a tomorrow list.",
      "Stop stressful scrolling before bed.",
      "Use light movement and daylight exposure in the morning."
    ],
    countryExample:
      "For students and young workers, a practical sleep reset is often more useful than a generic lecture on productivity.",
    metric: {
      label: "Reset window",
      value: "3 days",
      meaning: "A fixed wake-up time for three days can begin stabilizing rhythm."
    }
  },
  {
    id: "climate-water-health",
    mode: "all",
    title: "Climate, water, and health are connected",
    tags: ["climate", "heat", "flood", "water", "health", "disease", "resilience", "sdg 13"],
    summary:
      "Climate stress links directly with water and health. Floods can contaminate drinking water, heat can worsen dehydration and stress, and drought can reduce hygiene and food security.",
    causes: [
      "Extreme rainfall overwhelms drainage and mixes sewage with drinking-water systems.",
      "Heatwaves increase dehydration, fatigue, and mental stress.",
      "Drought reduces clean water access and can raise household conflict over resources."
    ],
    impacts: [
      "More waterborne disease after floods.",
      "Higher risk for children, older adults, outdoor workers, and low-income families.",
      "Damage to schools, clinics, roads, and local livelihoods."
    ],
    actions: [
      "Create local risk maps for flood zones, water points, clinics, and schools.",
      "Prepare household emergency water plans before rainy seasons.",
      "Use early-warning messages in simple local language.",
      "Combine climate adaptation with clean-water and mental-health support."
    ],
    countryExample:
      "For Pakistan, flood resilience should not stop at rescue. It should include safe water, sanitation, disease monitoring, school continuity, and mental support.",
    metric: {
      label: "Connected SDGs",
      value: "3 + 6 + 13",
      meaning: "Health, water, and climate action should be planned together."
    }
  },
  {
    id: "community-project-design",
    mode: "learn",
    title: "How to design a small SDG project",
    tags: ["project", "ngo", "school", "community", "dashboard", "monitoring", "impact"],
    summary:
      "A good SDG project starts small: one local problem, one target group, one measurable baseline, one intervention, and one feedback loop. Big words do not create impact; clear measurement does.",
    causes: [
      "Many projects fail because they start with slogans instead of verified local pain points.",
      "Weak monitoring hides whether the solution actually works.",
      "No community ownership means the project dies after the first launch."
    ],
    impacts: [
      "A focused project is easier to fund, explain, and improve.",
      "Baseline data makes before/after impact visible.",
      "Community feedback keeps the solution realistic."
    ],
    actions: [
      "Write the problem in one sentence with location and affected group.",
      "Collect baseline data through surveys, observation, or public records.",
      "Define one success metric such as reduced complaints, improved attendance, or safer water points.",
      "Review results monthly and change the intervention if evidence is weak."
    ],
    countryExample:
      "A student project can map water points near a school, record illness complaints, add hygiene awareness, and compare attendance before and after intervention.",
    metric: {
      label: "Project formula",
      value: "1-1-1-1",
      meaning: "One problem, one group, one metric, one feedback loop."
    }
  }
];

export const modeLabels: Record<SageMode, string> = {
  learn: "Learn Mode",
  mindcare: "MindCare Mode",
  aqualife: "AquaLife Mode"
};

export const modeDescriptions: Record<SageMode, string> = {
  learn: "Explains SDG concepts, project ideas, causes, impacts, and practical solutions.",
  mindcare: "Gives supportive mental well-being guidance with safe escalation language.",
  aqualife: "Focuses on clean water, water pollution, sanitation, floods, and community health."
};
