import { KnowledgeItem, knowledgeBase, SageMode } from "./knowledge";

export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

const stopWords = new Set([
  "the", "is", "are", "a", "an", "to", "of", "and", "or", "in", "on", "for", "with", "about", "what", "how", "why", "can", "you", "me", "my", "it", "this", "that", "please", "tell", "explain"
]);

export function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 2 && !stopWords.has(t));
}

function itemText(item: KnowledgeItem): string {
  return [
    item.title,
    item.tags.join(" "),
    item.summary,
    item.causes.join(" "),
    item.impacts.join(" "),
    item.actions.join(" "),
    item.countryExample ?? ""
  ].join(" ");
}

export function retrieveKnowledge(message: string, mode: SageMode, limit = 3): KnowledgeItem[] {
  const queryTokens = tokenize(message);
  if (queryTokens.length === 0) {
    return knowledgeBase.filter((item) => item.mode === mode || item.mode === "all").slice(0, limit);
  }

  const scored = knowledgeBase
    .filter((item) => item.mode === mode || item.mode === "all")
    .map((item) => {
      const textTokens = tokenize(itemText(item));
      const textSet = new Set(textTokens);
      const tagSet = new Set(item.tags.map((tag) => tag.toLowerCase()));
      let score = 0;

      for (const token of queryTokens) {
        if (textSet.has(token)) score += 2;
        if (Array.from(tagSet).some((tag) => tag.includes(token))) score += 4;
      }

      if (item.mode === mode) score += 2;
      return { item, score };
    })
    .sort((a, b) => b.score - a.score);

  const best = scored.filter((entry) => entry.score > 0).slice(0, limit).map((entry) => entry.item);
  if (best.length > 0) return best;
  return knowledgeBase.filter((item) => item.mode === mode || item.mode === "all").slice(0, limit);
}

export function summarizeHistory(history: ChatMessage[] = []): string {
  const recent = history.slice(-6);
  if (recent.length === 0) return "No previous chat context.";
  return recent.map((msg) => `${msg.role}: ${msg.content.slice(0, 220)}`).join("\n");
}
