import { NextResponse } from "next/server";
import { respondWithSage } from "@/lib/agent";
import type { SageMode } from "@/lib/knowledge";

const allowedModes = new Set(["learn", "mindcare", "aqualife"]);

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const message = String(body?.message ?? "").trim();
    const mode = String(body?.mode ?? "learn") as SageMode;
    const history = Array.isArray(body?.history) ? body.history : [];

    if (!message) {
      return NextResponse.json({ error: "Message is required." }, { status: 400 });
    }

    if (!allowedModes.has(mode)) {
      return NextResponse.json({ error: "Invalid mode." }, { status: 400 });
    }

    const result = await respondWithSage({ message, mode, history });
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      {
        error: "Sage SDGs AI could not process the request.",
        detail: error instanceof Error ? error.message : "Unknown error"
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    name: "Sage SDGs AI",
    status: "ready-final-mindcare-upgrade",
    modes: ["learn", "mindcare", "aqualife"],
    voice: "Browser speech recognition and speech synthesis are handled on the client side.",
    mindcare: "Copilot-style local conversation layer with richer mental well-being support, follow-up questions, crisis detection, and safe boundaries."
  });
}
