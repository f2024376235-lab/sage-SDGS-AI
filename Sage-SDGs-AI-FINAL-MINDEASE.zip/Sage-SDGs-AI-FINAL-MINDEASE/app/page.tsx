import SageChat from "@/components/SageChat";

export default function HomePage() {
  return <SageChat />;
}
