import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sage SDGs AI",
  description: "A voice-enabled SDG learning, mental well-being, and clean-water AI assistant."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
