"use client";

import { FormEvent, useMemo, useRef, useState } from "react";
import { modeDescriptions, modeLabels, SageMode, sdgDashboard } from "@/lib/knowledge";

type Message = {
  role: "user" | "assistant";
  content: string;
  sources?: string[];
};

type ApiResponse = {
  answer: string;
  sources: string[];
  mode: SageMode;
  dashboardSpeech: string;
};

const samplePrompts: Record<SageMode, string[]> = {
  learn: [
    "Explain SDGs in a simple way with examples.",
    "How can I design a small SDG project for my university?",
    "Tell me how climate, health, and water are connected."
  ],
  mindcare: [
    "I feel stressed because of study pressure. Talk with me step by step.",
    "I am overthinking and cannot focus. Help me calm down.",
    "Give me a 60-second grounding routine and then ask me what happened."
  ],
  aqualife: [
    "Explain the water cycle basics like a proper AI teacher.",
    "How does water pollution affect health and education?",
    "Give me a clean-water action plan for a local community."
  ]
};

const modeStyles: Record<SageMode, string> = {
  learn: "border-sage-200 bg-sage-50/80 text-sage-900",
  mindcare: "border-emerald-200 bg-emerald-50/80 text-emerald-950",
  aqualife: "border-aqua-100 bg-aqua-50/80 text-cyan-950"
};

function getSpeechApi() {
  if (typeof window === "undefined") return null;
  return window.speechSynthesis ?? null;
}

function speakText(text: string) {
  const synth = getSpeechApi();
  if (!synth) return;
  synth.cancel();
  const clean = text
    .replace(/#{1,6}\s/g, "")
    .replace(/\*\*/g, "")
    .replace(/- /g, "")
    .replace(/\n+/g, ". ")
    .slice(0, 4200);
  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.rate = 0.94;
  utterance.pitch = 1;
  utterance.volume = 1;
  synth.speak(utterance);
}

function stopSpeaking() {
  const synth = getSpeechApi();
  if (synth) synth.cancel();
}

function dashboardSpeechText() {
  return `Sage SDGs AI dashboard summary. ${sdgDashboard
    .map((item) => `${item.label}, ${item.title}, current readiness score ${item.score} out of 100. ${item.note}`)
    .join(" ")} Use this dashboard to explain where action is strongest and where local improvement is needed.`;
}

export default function SageChat() {
  const [mode, setMode] = useState<SageMode>("aqualife");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content:
        "### Welcome to Sage SDGs AI\nI’m ready in Learn, MindCare, and AquaLife modes. MindCare now talks more like a guided Copilot: it reflects your problem, asks useful follow-up questions, gives tiny next steps, and handles crisis words safely. Voice input and voice output are active in all modes."
    }
  ]);
  const [loading, setLoading] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [listening, setListening] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState("Voice ready");
  const recognitionRef = useRef<any>(null);

  const currentPromptList = useMemo(() => samplePrompts[mode], [mode]);

  async function sendMessage(text: string) {
    const clean = text.trim();
    if (!clean || loading) return;

    const userMessage: Message = { role: "user", content: clean };
    const historyForApi = [...messages, userMessage].slice(-8).map((message) => ({
      role: message.role,
      content: message.content
    }));

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/sdg-agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: clean, mode, history: historyForApi })
      });

      if (!response.ok) {
        throw new Error("Agent API request failed.");
      }

      const data = (await response.json()) as ApiResponse;
      const assistantMessage: Message = {
        role: "assistant",
        content: data.answer,
        sources: data.sources
      };
      setMessages((prev) => [...prev, assistantMessage]);
      if (autoSpeak) speakText(data.answer);
    } catch (error) {
      const fallback =
        "Sage SDGs AI could not connect to the local API. Check that the app is running with npm run dev and that /api/sdg-agent is available.";
      setMessages((prev) => [...prev, { role: "assistant", content: fallback }]);
      if (autoSpeak) speakText(fallback);
    } finally {
      setLoading(false);
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void sendMessage(input);
  }

  function startVoiceCommand() {
    if (typeof window === "undefined") return;
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceStatus("Your browser does not support speech recognition. Use Chrome or Edge for voice command.");
      return;
    }

    stopSpeaking();
    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = "en-US";
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setListening(true);
      setVoiceStatus("Listening... ask your SDG question now.");
    };

    recognition.onerror = () => {
      setListening(false);
      setVoiceStatus("Voice input stopped. Check microphone permission and try again.");
    };

    recognition.onend = () => {
      setListening(false);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript || "";
      setInput(transcript);
      setVoiceStatus(`Heard: ${transcript}`);
      if (transcript.trim()) {
        void sendMessage(transcript);
      }
    };

    recognition.start();
  }

  function stopVoiceCommand() {
    recognitionRef.current?.stop?.();
    setListening(false);
    setVoiceStatus("Voice input stopped.");
  }

  function readLastAnswer() {
    const lastAssistant = [...messages].reverse().find((message) => message.role === "assistant");
    if (lastAssistant) speakText(lastAssistant.content);
  }

  return (
    <main className="min-h-screen px-4 py-6 md:px-8 lg:px-10">
      <section className="mx-auto flex max-w-7xl flex-col gap-6">
        <header className="glass-card overflow-hidden p-6 md:p-8">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-3xl">
              <div className="mb-3 inline-flex rounded-full border border-sage-200 bg-white/80 px-4 py-2 text-sm font-semibold text-sage-800">
Final MindCare Upgrade • Copilot-Style Chat • Replit Ready
              </div>
              <h1 className="text-4xl font-black tracking-tight text-slate-950 md:text-6xl">
                Sage <span className="text-sage-700">SDGs AI</span>
              </h1>
              <p className="mt-4 text-lg leading-8 text-slate-700">
                A practical SDG assistant for clean water, mental well-being, climate-health links, and community action. MindCare now uses a richer local support knowledge base, safer crisis handling, follow-up questions, and voice support.
              </p>
            </div>

            <div className="rounded-3xl border border-white bg-slate-950 p-5 text-white shadow-2xl lg:w-96">
              <p className="text-sm uppercase tracking-[0.25em] text-sage-200">Agent Status</p>
              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-2xl bg-white/10 p-4">
                  <p className="text-sage-100">Modes</p>
                  <p className="mt-1 text-2xl font-bold">3</p>
                </div>
                <div className="rounded-2xl bg-white/10 p-4">
                  <p className="text-sage-100">Voice</p>
                  <p className="mt-1 text-2xl font-bold">On</p>
                </div>
                <div className="rounded-2xl bg-white/10 p-4">
                  <p className="text-sage-100">MindCare</p>
                  <p className="mt-1 text-2xl font-bold">Smart</p>
                </div>
                <div className="rounded-2xl bg-white/10 p-4">
                  <p className="text-sage-100">Groq</p>
                  <p className="mt-1 text-2xl font-bold">Optional</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <section className="grid gap-4 lg:grid-cols-3">
          {(["learn", "mindcare", "aqualife"] as SageMode[]).map((item) => (
            <button
              key={item}
              onClick={() => setMode(item)}
              className={`mode-card text-left ${modeStyles[item]} ${mode === item ? "ring-4 ring-sage-300" : "opacity-85"}`}
            >
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-xl font-extrabold">{modeLabels[item]}</h2>
                <span className="rounded-full bg-white/80 px-3 py-1 text-xs font-bold">{mode === item ? "Active" : "Select"}</span>
              </div>
              <p className="mt-3 text-sm leading-6 opacity-80">{modeDescriptions[item]}</p>
            </button>
          ))}
        </section>

        <section className="grid gap-6 lg:grid-cols-[1fr_380px]">
          <div className="glass-card flex min-h-[680px] flex-col overflow-hidden">
            <div className="border-b border-white/80 bg-white/60 p-4 md:p-5">
              <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <p className="text-sm font-bold uppercase tracking-[0.18em] text-sage-700">Current Mode</p>
                  <h2 className="text-2xl font-black text-slate-950">{modeLabels[mode]}</h2>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={listening ? stopVoiceCommand : startVoiceCommand}
                    className={`soft-button ${listening ? "bg-red-600 text-white" : "bg-sage-700 text-white hover:bg-sage-800"}`}
                  >
                    {listening ? "Stop Mic" : "Voice Command"}
                  </button>
                  <button onClick={() => void sendMessage("I feel overwhelmed. Start a 60-second grounding exercise and then ask me one question.")} className="soft-button bg-white text-emerald-800 hover:bg-emerald-50">
                    Ground Me
                  </button>
                  <button onClick={readLastAnswer} className="soft-button bg-white text-sage-800 hover:bg-sage-50">
                    Read Answer
                  </button>
                  <button onClick={stopSpeaking} className="soft-button bg-white text-slate-700 hover:bg-slate-50">
                    Stop Voice
                  </button>
                </div>
              </div>
              <div className="mt-3 flex flex-col gap-2 rounded-2xl border border-sage-100 bg-sage-50/75 p-3 text-sm text-sage-900 md:flex-row md:items-center md:justify-between">
                <span>{voiceStatus}</span>
                <label className="flex cursor-pointer items-center gap-2 font-semibold">
                  <input
                    type="checkbox"
                    checked={autoSpeak}
                    onChange={(event) => setAutoSpeak(event.target.checked)}
                    className="h-4 w-4 accent-sage-700"
                  />
                  Auto-read replies
                </label>
              </div>
            </div>

            <div className="sage-scroll flex-1 space-y-4 overflow-y-auto p-4 md:p-6">
              {messages.map((message, index) => (
                <article
                  key={`${message.role}-${index}`}
                  className={`max-w-[92%] rounded-3xl p-4 shadow-sm md:p-5 ${
                    message.role === "user"
                      ? "ml-auto bg-sage-700 text-white"
                      : "mr-auto border border-white bg-white/90 text-slate-800"
                  }`}
                >
                  <div className="mb-2 text-xs font-black uppercase tracking-[0.16em] opacity-70">
                    {message.role === "user" ? "You" : "Sage SDGs AI"}
                  </div>
                  <div className="whitespace-pre-wrap text-sm leading-7 md:text-[15px]">{message.content}</div>
                  {message.sources && message.sources.length > 0 && (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {message.sources.map((source) => (
                        <span key={source} className="rounded-full bg-sage-50 px-3 py-1 text-xs font-bold text-sage-800">
                          {source}
                        </span>
                      ))}
                    </div>
                  )}
                </article>
              ))}
              {loading && (
                <div className="mr-auto rounded-3xl border border-white bg-white/90 p-5 text-sm font-semibold text-sage-800 shadow-sm">
                  Sage is thinking with the SDG knowledge base...
                </div>
              )}
            </div>

            <div className="border-t border-white/80 bg-white/60 p-4 md:p-5">
              <div className="mb-3 flex flex-wrap gap-2">
                {currentPromptList.map((prompt) => (
                  <button
                    key={prompt}
                    onClick={() => void sendMessage(prompt)}
                    className="rounded-full border border-sage-100 bg-white/90 px-3 py-2 text-xs font-semibold text-sage-800 hover:bg-sage-50"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
              <form onSubmit={handleSubmit} className="flex flex-col gap-3 md:flex-row">
                <textarea
                  value={input}
                  onChange={(event) => setInput(event.target.value)}
                  placeholder="Ask Sage SDGs AI about water pollution, mental well-being, SDG basics, or community solutions..."
                  rows={2}
                  className="min-h-[58px] flex-1 resize-none rounded-2xl border border-sage-100 bg-white/95 px-4 py-3 text-sm outline-none ring-sage-200 transition focus:ring-4"
                />
                <button
                  type="submit"
                  disabled={loading || !input.trim()}
                  className="soft-button bg-slate-950 text-white hover:bg-slate-800 md:w-36"
                >
                  Send
                </button>
              </form>
            </div>
          </div>

          <aside className="space-y-6">
            <section className="glass-card p-5">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-bold uppercase tracking-[0.18em] text-sage-700">Dashboard</p>
                  <h2 className="mt-1 text-2xl font-black text-slate-950">SDG Focus Data</h2>
                </div>
                <button
                  onClick={() => speakText(dashboardSpeechText())}
                  className="soft-button bg-aqua-700 text-white hover:bg-cyan-800"
                >
                  Read Data
                </button>
              </div>
              <div className="mt-5 space-y-4">
                {sdgDashboard.map((item) => (
                  <div key={item.label} className="rounded-2xl border border-white bg-white/85 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="text-xs font-black uppercase tracking-[0.14em] text-sage-700">{item.label}</p>
                        <h3 className="font-extrabold text-slate-950">{item.title}</h3>
                      </div>
                      <span className="rounded-full bg-sage-100 px-3 py-1 text-sm font-black text-sage-800">{item.score}</span>
                    </div>
                    <div className="mt-3 h-3 overflow-hidden rounded-full bg-slate-100">
                      <div className="h-full rounded-full bg-sage-600" style={{ width: `${item.score}%` }} />
                    </div>
                    <p className="mt-3 text-sm leading-6 text-slate-600">{item.note}</p>
                  </div>
                ))}
              </div>
            </section>

            <section className="glass-card p-5">
              <p className="text-sm font-bold uppercase tracking-[0.18em] text-sage-700">What was upgraded</p>
              <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-700">
                <li><strong>Voice command:</strong> ask questions through the browser microphone.</li>
                <li><strong>Voice output:</strong> Sage reads replies and dashboard data aloud.</li>
                <li><strong>All modes:</strong> voice works in Learn, MindCare, and AquaLife.</li>
                <li><strong>MindCare database:</strong> academic stress, anxiety, low mood, burnout, sleep, loneliness, and climate/water distress patterns.</li>
                <li><strong>Copilot-style flow:</strong> reflects the problem, asks follow-ups, gives tiny next steps, and remembers recent context.</li>
                <li><strong>Safety layer:</strong> stronger crisis and high-risk response logic.</li>
                <li><strong>Replit ready:</strong> includes .replit and Node config.</li>
              </ul>
            </section>

            <section className="rounded-3xl border border-amber-200 bg-amber-50/90 p-5 text-amber-950 shadow-lg">
              <h2 className="text-lg font-black">Important safety logic</h2>
              <p className="mt-2 text-sm leading-6">
                MindCare mode gives general support only. It does not diagnose or replace professional help. Crisis language triggers safer escalation guidance.
              </p>
            </section>
          </aside>
        </section>
      </section>
    </main>
  );
}
