# Sage SDGs AI — Final MindCare Upgrade

Sage SDGs AI is a Replit-ready Next.js assistant for Sustainable Development Goals. It includes Learn Mode, AquaLife Mode, and an upgraded MindCare Mode.

## Final modification included

This package upgrades the chat behavior so the agent talks more like a guided Copilot instead of a dry chatbot.

### MindCare upgrades

- Richer local mental well-being knowledge base
- Academic stress support
- Anxiety and overthinking support
- Low mood and motivation support
- Sleep and burnout support
- Climate, water, and community distress support
- Crisis/self-harm safety detection
- High-risk safety check responses
- Follow-up questions after each support answer
- Tiny next-step coaching instead of generic motivation
- Recent conversation continuity
- Optional Groq API support for stronger LLM responses

### Existing project features preserved

- Sage SDGs AI branding
- Learn, MindCare, and AquaLife modes
- Clean SDG dashboard
- Voice command through browser microphone
- Voice output/read-aloud replies
- Read dashboard data aloud
- Local fallback responses, so the app still works without an API key
- Replit-ready config files

## Important safety note

MindCare is for general well-being education and emotional support. It is not a doctor, therapist, emergency service, or diagnostic tool. Crisis/self-harm language triggers safer escalation guidance.

## How to run

```bash
npm install
npm run dev
```

Open the Replit web preview or go to:

```bash
http://localhost:3000
```

## Optional Groq setup

Create a `.env.local` file:

```bash
GROQ_API_KEY=your_groq_api_key_here
GROQ_MODEL=llama-3.1-8b-instant
```

The local MindCare safety layer still protects crisis responses even when Groq is enabled.

## Best test prompts

Try these in MindCare Mode:

```text
I feel stressed because of study pressure. Talk with me step by step.
```

```text
I am overthinking and cannot focus. Help me calm down.
```

```text
I cannot sleep because I keep thinking about my deadlines.
```

Try these in AquaLife Mode:

```text
Explain water pollution like a proper AI teacher.
```

```text
Create a community action plan for clean drinking water.
```

## Notes about the Kaggle reference

The final upgrade follows the requested AI MindEase-style direction: supportive mental-health conversation, safe escalation, and agent-like guidance. The exact Kaggle page is not bundled as a dataset file. Instead, the project includes a custom local TypeScript knowledge base and decision layer built for your Sage SDGs AI app.
