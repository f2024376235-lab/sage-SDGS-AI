import type { SdgMode } from "@/lib/types";

export type KnowledgeRecord = {
  id: string;
  mode: SdgMode;
  sdg: string;
  topic: string;
  keywords: string[];
  evidence: string;
  guidance: string;
  actions: string[];
  escalation?: string;
  source: string;
};

export const knowledgeBase: Record<SdgMode, KnowledgeRecord[]> = {
  learn: [
    {
      id: "learn-active-recall-001",
      mode: "learn",
      sdg: "SDG 4",
      topic: "Active recall and spaced revision",
      keywords: ["study", "exam", "revision", "memorize", "learn", "quiz", "test", "mcq", "presentation", "paper"],
      evidence: "Students retain more when they retrieve knowledge from memory, test weak points, and review after short intervals instead of rereading passively.",
      guidance: "Turn every topic into questions, answer without notes, check mistakes, and repeat the weak parts later.",
      actions: [
        "Convert the topic into 5 short questions before reading deeply.",
        "Answer from memory first, then check the notes.",
        "Review weak points after 20 minutes, 1 day, and 3 days.",
        "Track one score: correct answers out of total questions."
      ],
      source: "Internal SDG 4 education strategy dataset"
    },
    {
      id: "learn-study-plan-002",
      mode: "learn",
      sdg: "SDG 4",
      topic: "Personalized study planning",
      keywords: ["plan", "schedule", "timetable", "deadline", "tomorrow", "prepare", "chapter", "slides"],
      evidence: "A useful study plan reduces cognitive load by separating understanding, practice, feedback, and review into small blocks.",
      guidance: "Use short blocks with a visible output from each block: notes, solved questions, flashcards, or a mini explanation.",
      actions: [
        "List topics from hardest to easiest.",
        "Spend the first block on the hardest high-mark topic.",
        "End each block with a self-test, not more reading.",
        "Leave the final 20% of time only for revision and mistakes."
      ],
      source: "Internal SDG 4 education strategy dataset"
    },
    {
      id: "learn-sdg-literacy-003",
      mode: "learn",
      sdg: "SDG 4",
      topic: "Sustainable Development Goals literacy",
      keywords: ["sdg", "sustainable", "development", "quality education", "health", "water", "sanitation", "community"],
      evidence: "SDG learning becomes stronger when learners connect abstract goals to local problems, measurable indicators, and community actions.",
      guidance: "Explain the SDG, identify the local problem, measure one indicator, and suggest one practical intervention.",
      actions: [
        "Define the selected SDG in one line.",
        "Connect it to one local example.",
        "Identify who is affected and how.",
        "Suggest one realistic action at school, home, or community level."
      ],
      source: "Internal SDG education dataset"
    }
  ],
  mindcare: [
    {
      id: "mindcare-stress-001",
      mode: "mindcare",
      sdg: "SDG 3",
      topic: "Stress overload and grounding",
      keywords: ["stress", "stressed", "pressure", "overwhelmed", "panic", "presentation", "exam", "deadline", "can't focus", "tension"],
      evidence: "When stress rises, the body often moves into threat mode. Slow breathing, grounding, and breaking the task into one next step can reduce immediate pressure.",
      guidance: "Do not try to solve everything at once. Stabilize the body first, name the main stressor, then choose one small action.",
      actions: [
        "Try 4-4-6 breathing for 3 minutes: inhale 4, hold 4, exhale 6.",
        "Name five visible things around you to bring attention back to the present.",
        "Write one sentence: The main pressure right now is...",
        "Choose one action that takes less than 5 minutes."
      ],
      escalation: "If the person may harm themselves or someone else, emergency support is needed immediately.",
      source: "Internal mental well-being support dataset"
    },
    {
      id: "mindcare-burnout-002",
      mode: "mindcare",
      sdg: "SDG 3",
      topic: "Burnout-style exhaustion and recovery basics",
      keywords: ["burnout", "tired", "exhausted", "drained", "no energy", "can't sleep", "sleep", "low mood", "hopeless"],
      evidence: "Sustained overload can reduce motivation, attention, sleep quality, and emotional tolerance. Recovery usually starts with rest, routine, boundaries, and support.",
      guidance: "The goal is not a perfect life reset. The goal is to protect sleep, food, movement, and social support while reducing unnecessary load.",
      actions: [
        "Pick one recovery anchor today: sleep time, meal, water, short walk, or shower.",
        "Reduce one non-essential task for 24 hours.",
        "Message one trusted person and say you are overloaded.",
        "If this has lasted weeks or affects daily functioning, consider professional support."
      ],
      escalation: "If hopelessness includes self-harm thoughts, treat it as urgent and contact emergency support or a crisis helpline.",
      source: "Internal mental well-being support dataset"
    },
    {
      id: "mindcare-reflection-003",
      mode: "mindcare",
      sdg: "SDG 3",
      topic: "Safe reflection prompts",
      keywords: ["reflect", "journal", "thinking", "confused", "sad", "angry", "lonely", "family", "work", "relationship"],
      evidence: "Open-ended, non-judgmental reflection helps users identify emotions and needs without forcing disclosure or diagnosis.",
      guidance: "Use gentle prompts that focus on feelings, needs, boundaries, and one safe next step.",
      actions: [
        "Write: What am I feeling right now, without judging it?",
        "Write: What do I need in the next 30 minutes?",
        "Write: What is in my control, and what is not?",
        "Choose one supportive action: breathe, rest, ask for help, or organize the next task."
      ],
      escalation: "If the reflection reveals danger, self-harm risk, abuse, or severe symptoms, seek trusted human/professional help immediately.",
      source: "Internal mental well-being support dataset"
    }
  ],
  water: [
    {
      id: "water-microbial-001",
      mode: "water",
      sdg: "SDG 6 + SDG 3",
      topic: "Microbial contamination and diarrheal disease risk",
      keywords: ["diarrhea", "vomiting", "fever", "stomach", "sewage", "dirty", "brown", "cloudy", "tanker", "tap", "well", "hand pump", "cholera", "typhoid"],
      evidence: "Water contaminated by sewage or fecal matter can spread gastrointestinal infections. Risk is higher for infants, older adults, pregnant people, and immunocompromised people.",
      guidance: "Stop drinking suspicious water, use a safer source, document the issue, and report it to local water/public-health authorities.",
      actions: [
        "Avoid using suspicious water for drinking, cooking, brushing teeth, or baby formula.",
        "Use sealed bottled water or a verified safe source until the issue is checked.",
        "Record location, source type, color/smell, date/time, and people affected.",
        "Report to municipal water authority, local council, health department, school/clinic admin, or community health worker."
      ],
      escalation: "Bloody diarrhea, severe dehydration, repeated vomiting, unconsciousness, infants with symptoms, or symptoms in pregnancy need urgent medical care.",
      source: "Internal AquaLife water risk dataset"
    },
    {
      id: "water-chemical-002",
      mode: "water",
      sdg: "SDG 6 + SDG 3",
      topic: "Chemical smell, industrial discharge, and heavy-metal concern",
      keywords: ["chemical", "factory", "industrial", "oil", "fuel", "metal", "arsenic", "lead", "fluoride", "nitrate", "pesticide", "odor", "smell", "taste", "bitter"],
      evidence: "Chemical contamination cannot be judged safely by appearance alone. Boiling may not remove heavy metals or many chemicals and can sometimes concentrate contaminants.",
      guidance: "Treat chemical smell/taste or industrial discharge as a testing and reporting issue, not just a household filtering issue.",
      actions: [
        "Do not boil chemical-smelling water as the only safety step.",
        "Use an alternative verified safe source for drinking and cooking.",
        "Collect details: nearby factories, drains, agricultural runoff, smell, taste, and timing.",
        "Request water-quality testing from the relevant local authority, lab, NGO, or public-health office."
      ],
      escalation: "If multiple people develop severe symptoms or there is suspected poisoning, seek medical help and report urgently.",
      source: "Internal AquaLife water risk dataset"
    },
    {
      id: "water-country-action-003",
      mode: "water",
      sdg: "SDG 6 + SDG 3",
      topic: "Country-level clean water improvement plan",
      keywords: ["country", "national", "government", "policy", "fix water", "water pollution", "eco", "environment", "sanitation", "community", "safe water", "clean water", "wastewater"],
      evidence: "Clean-water improvement works best when source protection, treatment, testing, sanitation, behavior change, and public reporting are handled together instead of as separate projects.",
      guidance: "A country-level plan should map risks, prioritize high-burden districts, upgrade treatment, enforce wastewater rules, publish water testing data, and protect vulnerable communities.",
      actions: [
        "Map water risks by district: microbial, arsenic/fluoride, industrial discharge, salinity, and tanker quality.",
        "Prioritize schools, clinics, low-income settlements, flood-affected areas, and rural water points.",
        "Set up routine testing with public dashboards and clear color-coded risk levels.",
        "Control pollution at source through sewage treatment, industrial compliance, and safe waste disposal.",
        "Create simple citizen reporting: photo, location, source type, symptoms, and urgency level."
      ],
      escalation: "Outbreak signals, multiple households sick, sewage mixing, or chemical spill reports need rapid public-health response.",
      source: "Internal AquaLife policy and community-action dataset"
    },
    {
      id: "water-household-004",
      mode: "water",
      sdg: "SDG 6 + SDG 3",
      topic: "Household water safety and reporting",
      keywords: ["filter", "boil", "home", "house", "school", "children", "family", "report", "complaint", "what should we do"],
      evidence: "Household steps can reduce short-term exposure, but persistent contamination requires source investigation and public authority action.",
      guidance: "Use immediate safety steps, keep evidence, and report the problem with enough detail that authorities can act.",
      actions: [
        "Use a safer source temporarily for drinking and cooking.",
        "Keep containers clean and covered to avoid recontamination.",
        "Take photos/videos only if safe and respectful.",
        "Submit a report with exact location, water source, visible signs, smell/taste, duration, and affected people."
      ],
      escalation: "Severe symptoms or vulnerable people affected should not wait for online guidance; seek medical care quickly.",
      source: "Internal AquaLife household safety dataset"
    }
  ]
};

function tokenize(text: string) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2);
}

export function retrieveKnowledge(mode: SdgMode, message: string, payload: Record<string, unknown> = {}) {
  const payloadText = Object.values(payload)
    .map((value) => String(value ?? ""))
    .join(" ");
  const query = `${message} ${payloadText}`.toLowerCase();
  const queryTokens = new Set(tokenize(query));

  return knowledgeBase[mode]
    .map((record) => {
      let score = 0;
      for (const keyword of record.keywords) {
        const lowerKeyword = keyword.toLowerCase();
        if (query.includes(lowerKeyword)) score += 8;
        if (queryTokens.has(lowerKeyword)) score += 4;
      }
      for (const token of queryTokens) {
        if (record.topic.toLowerCase().includes(token)) score += 2;
        if (record.evidence.toLowerCase().includes(token)) score += 1;
        if (record.guidance.toLowerCase().includes(token)) score += 1;
      }
      return { record, score };
    })
    .sort((a, b) => b.score - a.score)
    .filter((item) => item.score > 0)
    .slice(0, 3)
    .map((item) => item.record);
}
