import type { AgentRequest, AgentResponse, SdgMode } from "@/lib/types";
import {
  getDatasetManifest,
  getDatasetMatchesForResponse,
  getModeDatasetSummary,
  retrieveExperienceRecords,
  type ExperienceRecord
} from "@/lib/experience-dataset";

const severeDistressKeywords = [
  "suicide",
  "kill myself",
  "self harm",
  "self-harm",
  "hurt myself",
  "end my life",
  "can't live",
  "cannot live",
  "want to die",
  "die"
];

const dangerousWaterKeywords = [
  "vomiting blood",
  "bloody diarrhea",
  "blood in stool",
  "severe dehydration",
  "unconscious",
  "blue lips",
  "can't breathe",
  "cannot breathe",
  "seizure",
  "chemical spill",
  "poison",
  "infant",
  "baby",
  "pregnant",
  "multiple people sick"
];

function clean(input: string) {
  return input.trim().replace(/\s+/g, " ").slice(0, 4000);
}

function includesAny(text: string, keywords: string[]) {
  const lower = text.toLowerCase();
  return keywords.some((keyword) => lower.includes(keyword));
}

function unique(items: string[], limit = 8) {
  return Array.from(new Set(items.filter(Boolean))).slice(0, limit);
}

function firstSentence(text: string) {
  return text.split(/(?<=[.!?])\s+/)[0] || text;
}

function getHistory(payload: Record<string, unknown> = {}) {
  const raw = payload.chatHistory;
  if (!Array.isArray(raw)) return [];
  return raw
    .slice(-6)
    .map((item) => {
      if (!item || typeof item !== "object") return "";
      const maybe = item as Record<string, unknown>;
      return `${String(maybe.role ?? "user")}: ${String(maybe.content ?? "")}`.slice(0, 240);
    })
    .filter(Boolean);
}

function datasetEvidenceLine(records: ExperienceRecord[]) {
  const topics = records.slice(0, 3).map((record) => `${record.topic} (${record.sdg})`);
  return topics.length ? topics.join(" + ") : "general SDG safety knowledge";
}

function datasetInsights(records: ExperienceRecord[]) {
  return records.slice(0, 4).map((record) => `${record.topic}: ${firstSentence(record.evidence)}`);
}

function baseData(mode: SdgMode, records: ExperienceRecord[], extra: Record<string, unknown> = {}) {
  return {
    generatedBy: "local-experience-dataset-agent",
    datasetSummary: getModeDatasetSummary(mode),
    datasetMatches: getDatasetMatchesForResponse(records),
    kaggleReadySources: getDatasetManifest().filter((item) => item.domain === mode || (mode === "water" && item.domain === "water")),
    ...extra
  };
}

function composeConversationalLearn(message: string, records: ExperienceRecord[]) {
  const lower = message.toLowerCase();
  const asksBasics = /basic|basics|what is|explain|cycle|sdg/.test(lower);
  const asksPlan = /plan|schedule|prepare|study|timetable|routine|deadline/.test(lower);
  const asksQuiz = /quiz|mcq|question|test|practice/.test(lower);

  if (asksQuiz) {
    return [
      "Yes — I’ll turn this into a learning check, not a shortcut. The point is to see what you can recall and apply by yourself.",
      "Mini quiz: 1) Define the topic in one sentence. 2) Give one real-life example. 3) Explain one cause and one effect. 4) Name one common beginner mistake. 5) Write one 5-line exam answer from memory.",
      "After you answer, Sage can score your weak area and update the progress dashboard. That is the proper SDG 4 style: learning, feedback, and improvement."
    ].join("\n\n");
  }

  if (asksPlan) {
    return [
      "Here’s the practical study-plan version. Do not just read; reading feels productive but often hides weak memory.",
      "Use a 4-step cycle: understand the idea, close the notes, recall it without help, then fix only the weak part. For a one-day plan, repeat this cycle 3–4 times with short breaks. For a one-week plan, repeat the same topic after 24 hours and again after 3 days.",
      "Progress should be tracked with three simple numbers: confidence before, quiz score after, and weak topic count. That is enough for a clean dashboard and presentation."
    ].join("\n\n");
  }

  if (asksBasics) {
    return [
      "SDG basics are simple when you think in systems. The Sustainable Development Goals are not just charity goals; they are a framework for fixing connected problems: education, health, water, poverty, climate, equality, jobs, and institutions.",
      "The cycle is: identify the problem, measure it with indicators, understand who is affected, choose an intervention, monitor results, then improve the intervention. For example, unsafe water is not only SDG 6. It also affects SDG 3 because people get sick, and SDG 4 because children miss school.",
      "So if someone asks Sage about water pollution, the agent should not only say ‘drink clean water.’ It should think like this: source of contamination → health risk → affected people → reporting path → infrastructure or policy fix → dashboard tracking. That is the proper SDG-agent behavior."
    ].join("\n\n");
  }

  return [
    `I’ll explain this through the SDG 4 learning lens. The dataset match is ${datasetEvidenceLine(records)}.`,
    "First, define the idea simply. Second, connect it to one real-life problem. Third, test understanding with a question. That method makes the answer useful instead of just looking fancy.",
    "Tell me the exact topic, and I can turn it into a beginner explanation, exam answer, quiz, or study plan."
  ].join("\n\n");
}

function getLearnResponse(request: AgentRequest, records: ExperienceRecord[]): AgentResponse {
  const message = clean(request.message || "Explain SDG basics");
  const lower = message.toLowerCase();
  const chatText = composeConversationalLearn(message, records);
  const actions = lower.includes("quiz")
    ? ["Answer the 5 mini-quiz questions first.", "Compare your answer with the explanation.", "Record your weak topic in the dashboard.", "Repeat the weakest concept tomorrow."]
    : lower.includes("plan") || lower.includes("study")
      ? ["Use understand → recall → check → fix.", "Track confidence before and after.", "Create a wrong-answer log.", "Review weak topics after 24 hours."]
      : ["Define the topic in one sentence.", "Connect it to a local example.", "Ask one active-recall question.", "Track the result as progress."];

  return {
    mode: "learn",
    title: "Learn Mode: SDG 4 Learning Agent",
    summary: firstSentence(chatText),
    chatText,
    safetyLevel: "low",
    actions: unique([...actions, ...records.flatMap((record) => record.actions)], 8),
    followUpQuestions: [
      "Do you want this as a beginner explanation, exam answer, quiz, or study plan?",
      "Which topic should I teach next?",
      "How much time do you have before the presentation or test?"
    ],
    datasetInsights: datasetInsights(records),
    data: baseData("learn", records, { progressDelta: 10, skill: records[0]?.topic ?? "SDG learning" })
  };
}

function getMindcareResponse(request: AgentRequest, records: ExperienceRecord[]): AgentResponse {
  const message = clean(request.message || "I feel stressed");
  const history = getHistory(request.payload ?? {});

  if (includesAny(message, severeDistressKeywords)) {
    const chatText = [
      "I’m really sorry you’re feeling this much pain. Your safety matters more than continuing this chat right now.",
      "Please contact emergency services or a trusted person near you immediately. If you might hurt yourself, do not stay alone and move away from anything you could use to harm yourself.",
      "Sage can stay supportive, but this needs real human help now. Say this clearly to someone nearby: ‘I am not safe alone right now.’"
    ].join("\n\n");

    return {
      mode: "mindcare",
      title: "MindCare Mode: Immediate Safety Support",
      summary: firstSentence(chatText),
      chatText,
      disclaimer: "MindCare does not diagnose, treat, or replace emergency or professional mental-health care. If you may harm yourself or someone else, contact emergency services immediately.",
      safetyLevel: "emergency",
      actions: [
        "Move away from anything you could use to harm yourself.",
        "Call emergency services or a trusted person immediately.",
        "Do not stay alone if you feel unsafe.",
        "Use clear words: I am not safe alone right now."
      ],
      followUpQuestions: ["Are you in immediate physical danger right now?", "Is there someone near you who can stay with you?"],
      datasetInsights: datasetInsights(records),
      data: baseData("mindcare", records, { risk: "severe distress keyword detected", historyUsed: history.length })
    };
  }

  const isWorkplace = /factory|job|office|boss|employee|workplace|industrial/.test(message.toLowerCase());
  const isPresentation = /presentation|viva|interview|speech|stage/.test(message.toLowerCase());
  const isBurnout = /burnout|exhausted|drained|no energy|tired/.test(message.toLowerCase());

  let focus = "We start by lowering pressure, naming the feeling, and choosing one small next action.";
  if (isPresentation) focus = "For presentation stress, the goal is not to become fearless; the goal is to become steady enough to perform the next step.";
  if (isBurnout) focus = "For burnout-style exhaustion, the smart move is not more pressure. Protect recovery anchors first: sleep, food, water, movement, and support.";
  if (isWorkplace) focus = "For workplace or industrial stress, do not blame only the individual. Look at workload, breaks, safety culture, communication, and support.";

  const chatText = [
    `I hear you. I’ll respond in MindCare mode using the experience dataset match: ${datasetEvidenceLine(records)}.`,
    `${focus} Try this now: inhale for 4 seconds, hold for 4 seconds, exhale for 6 seconds. Do it three times before making any big decision.`,
    "Now answer one safe reflection question: what is the biggest pressure right now — time, fear of failure, workload, people, health, money, or uncertainty? Once we name it, Sage can build a small plan without pretending to diagnose you.",
    history.length ? `I also see recent chat context in this session, so I will keep the response connected instead of treating every message like a new start.` : ""
  ].filter(Boolean).join("\n\n");

  return {
    mode: "mindcare",
    title: "MindCare Mode: Human-Like Supportive Agent",
    summary: firstSentence(chatText),
    chatText,
    disclaimer: "MindCare provides general well-being support only. It cannot diagnose conditions, prescribe treatment, or replace qualified mental-health care. If symptoms feel severe, unsafe, or persistent, seek professional support.",
    safetyLevel: "medium",
    actions: unique([
      "Do 4-4-6 breathing for 2 minutes.",
      "Name the main feeling in plain words.",
      "Choose one action that takes less than 5 minutes.",
      "If this affects sleep, appetite, daily functioning, or safety, talk to a qualified professional.",
      ...records.flatMap((record) => record.actions)
    ], 8),
    followUpQuestions: [
      "Do you want a 2-minute breathing guide or a reflection prompt?",
      "Is this mainly study pressure, work pressure, family pressure, or future pressure?",
      "How intense is it from 1 to 10 right now?"
    ],
    datasetInsights: datasetInsights(records),
    data: baseData("mindcare", records, { exercise: "4-4-6 breathing", recommendedDurationMinutes: 2, historyUsed: history.length })
  };
}

function waterUrgency(message: string) {
  const lower = message.toLowerCase();
  if (includesAny(lower, dangerousWaterKeywords)) return "emergency" as const;
  if (/chemical|factory|industrial|sewage|bloody|diarrhea|vomiting|fever|flood|children|school/.test(lower)) return "high" as const;
  if (/smell|taste|brown|cloudy|dirty|report|complaint/.test(lower)) return "medium" as const;
  return "medium" as const;
}

function getWaterResponse(request: AgentRequest, records: ExperienceRecord[]): AgentResponse {
  const message = clean(request.message || "How can a country reduce water pollution?");
  const payload = request.payload ?? {};
  const location = String(payload.location ?? "the affected area");
  const category = String(payload.category ?? "water quality concern");
  const symptoms = String(payload.symptoms ?? "not specified");
  const peopleAffected = String(payload.peopleAffected ?? "not specified");
  const combined = `${message} ${location} ${category} ${symptoms} ${peopleAffected}`;
  const urgency = waterUrgency(combined);

  if (urgency === "emergency") {
    const chatText = [
      "This is not a normal water-quality question anymore; this is an urgent safety situation because the report includes danger signals or vulnerable people.",
      `For ${location}, stop exposure first. Do not use the suspected water for drinking, cooking, brushing teeth, or preparing baby formula. Use sealed bottled water or a verified safe source until the issue is checked.`,
      "Seek urgent medical care for severe dehydration, bloody diarrhea, repeated vomiting, unconsciousness, breathing difficulty, infants, pregnant people, elderly people, or multiple people becoming sick. Report the issue with exact location, water source, symptoms, and timing."
    ].join("\n\n");

    return {
      mode: "water",
      title: "AquaLife Mode: Urgent Water Safety Response",
      summary: firstSentence(chatText),
      chatText,
      disclaimer: "AquaLife gives informational water-risk guidance only. It cannot confirm contamination, diagnose illness, or replace medical/public-health testing. Severe symptoms need urgent professional help.",
      safetyLevel: "emergency",
      actions: unique([
        "Seek urgent medical care for severe symptoms or vulnerable people.",
        "Stop using suspected water for drinking, cooking, brushing teeth, or baby formula.",
        "Use sealed bottled water or a verified safe source.",
        "Report exact location, source type, color/smell/taste, symptoms, and people affected.",
        ...records.flatMap((record) => record.actions)
      ], 8),
      followUpQuestions: [
        "What is the exact location or nearest landmark?",
        "Is the source tap, hand pump, well, tanker, filter plant, canal, or drain?",
        "Are infants, elderly people, or pregnant people affected?"
      ],
      datasetInsights: datasetInsights(records),
      data: baseData("water", records, { location, category, symptoms, peopleAffected, urgency })
    };
  }

  const countryPlanning = /country|national|government|policy|fix water|water pollution|system|district|province|city|pakistan|india|africa/.test(combined.toLowerCase());

  const chatText = countryPlanning
    ? [
        "Yes, I get what you mean. AquaLife should talk like a clean-water action agent, not like a simple FAQ bot. So here is the proper country-level answer.",
        "To fix water pollution in a country, you do not start with one filter. You start with a system map: where the water comes from, where sewage enters, where industries discharge, which districts have disease clusters, and which communities are most exposed. That gives the government a risk map instead of random complaints.",
        "Then the country needs five layers: 1) test water routinely, 2) treat drinking water, 3) treat sewage and industrial wastewater before it enters rivers or groundwater, 4) publish public dashboards so citizens can see risk levels, and 5) make reporting simple through photos, location, source type, symptoms, and urgency.",
        "For example, if a city has brown tap water and stomach illness reports, Sage classifies it as a possible microbial/sewage risk. If water has a chemical smell near factories, Sage treats it as an industrial-discharge testing issue because boiling may not solve chemical contamination. This is how the agent uses dataset-style experience: problem → risk type → affected people → urgent action → authority report → long-term infrastructure fix."
      ].join("\n\n")
    : [
        `I’ll analyze this as an AquaLife water-risk report. The dataset match is ${datasetEvidenceLine(records)}.`,
        `Location: ${location}. Category: ${category}. Symptoms/notes: ${symptoms}. People affected: ${peopleAffected}. Based on the message, I would treat this as ${urgency} urgency until a trusted authority or lab checks it.`,
        "The safe logic is: reduce exposure first, document the signs, report through the correct channel, then push for testing and source-level fixing. Household filters can help in some cases, but they are not a full solution for sewage mixing, industrial discharge, arsenic, fluoride, pesticides, or flood contamination.",
        "A good report should include exact location, source type, color, smell, taste, illness signs, number of people affected, time started, and photos only if safe."
      ].join("\n\n");

  return {
    mode: "water",
    title: countryPlanning ? "AquaLife Mode: Country Clean-Water Action Agent" : "AquaLife Mode: Dataset-Informed Water Risk Chat",
    summary: firstSentence(chatText),
    chatText,
    disclaimer: "AquaLife is for water-risk awareness and reporting guidance only. It does not confirm contamination, diagnose illness, or replace medical/public-health testing.",
    safetyLevel: urgency,
    actions: unique([
      "Reduce exposure to suspicious water first.",
      "Document location, source type, signs, symptoms, and people affected.",
      "Report to municipal water authority, health department, environment agency, school/clinic admin, or community health worker.",
      "Request testing when chemical, industrial, sewage, or repeated illness signals appear.",
      ...records.flatMap((record) => record.actions)
    ], 9),
    followUpQuestions: [
      "Which country, city, or district should the plan focus on?",
      "Is the concern microbial, industrial/chemical, flood-related, or unknown?",
      "Do you want a citizen-report workflow or a government dashboard workflow?"
    ],
    datasetInsights: datasetInsights(records),
    data: baseData("water", records, { location, category, symptoms, peopleAffected, urgency, countryPlanning })
  };
}

function responseForMode(request: AgentRequest, records: ExperienceRecord[]): AgentResponse {
  if (request.mode === "learn") return getLearnResponse(request, records);
  if (request.mode === "mindcare") return getMindcareResponse(request, records);
  return getWaterResponse(request, records);
}

type GroqChoice = { message?: { content?: string } };
type GroqResponse = { choices?: GroqChoice[] };

function extractJson(text: string) {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(text.slice(start, end + 1)) as Partial<AgentResponse>;
  } catch {
    return null;
  }
}

function normalizeGroqResponse(candidate: Partial<AgentResponse>, fallback: AgentResponse, records: ExperienceRecord[]): AgentResponse {
  const chatText = typeof candidate.chatText === "string" ? candidate.chatText.slice(0, 3500) : typeof candidate.summary === "string" ? candidate.summary.slice(0, 2500) : fallback.chatText;
  return {
    mode: fallback.mode,
    title: typeof candidate.title === "string" ? candidate.title.slice(0, 140) : fallback.title,
    summary: typeof candidate.summary === "string" ? candidate.summary.slice(0, 1600) : fallback.summary,
    chatText,
    disclaimer: typeof candidate.disclaimer === "string" ? candidate.disclaimer.slice(0, 700) : fallback.disclaimer,
    safetyLevel: ["low", "medium", "high", "emergency"].includes(String(candidate.safetyLevel))
      ? (candidate.safetyLevel as AgentResponse["safetyLevel"])
      : fallback.safetyLevel,
    actions: Array.isArray(candidate.actions) && candidate.actions.length ? candidate.actions.map(String).slice(0, 9) : fallback.actions,
    followUpQuestions: Array.isArray(candidate.followUpQuestions) && candidate.followUpQuestions.length ? candidate.followUpQuestions.map(String).slice(0, 4) : fallback.followUpQuestions,
    datasetInsights: Array.isArray(candidate.datasetInsights) ? candidate.datasetInsights.map(String).slice(0, 4) : fallback.datasetInsights,
    data: {
      ...(fallback.data ?? {}),
      ...(candidate.data ?? {}),
      generatedBy: "groq-plus-local-experience-dataset",
      datasetMatches: getDatasetMatchesForResponse(records)
    }
  };
}

async function tryGroqResponse(request: AgentRequest, records: ExperienceRecord[], fallback: AgentResponse) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) return null;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 9000);

  try {
    const systemPrompt = `You are Sage SDG AI, a human-like mega-agent for SDG 4 Learn Mode, SDG 3 MindCare Mode, and SDG 6 AquaLife Mode linked to health. Reply like a real chat assistant, not a static card. Use retrieved experience records as your data context. Always keep safety: no diagnosis, no prescriptions, no academic dishonesty. For self-harm, severe distress, severe water symptoms, chemical spills, infants, pregnancy, or multiple people sick, escalate to professional/emergency help. Return JSON only with: title, summary, chatText, disclaimer, safetyLevel, actions, followUpQuestions, datasetInsights, data.`;

    const userPrompt = JSON.stringify({
      activeMode: request.mode,
      userMessage: request.message,
      payload: request.payload ?? {},
      retrievedExperienceDataset: records,
      requiredTone: "conversational, practical, human-like, dataset-informed, SDG action focused",
      fallbackResponse: fallback
    });

    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: process.env.GROQ_MODEL || "llama-3.1-8b-instant",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        temperature: 0.4,
        max_tokens: 1300,
        response_format: { type: "json_object" }
      }),
      signal: controller.signal
    });

    if (!res.ok) return null;
    const data = (await res.json()) as GroqResponse;
    const content = data.choices?.[0]?.message?.content;
    if (!content) return null;
    const parsed = extractJson(content);
    if (!parsed) return null;
    return normalizeGroqResponse(parsed, fallback, records);
  } catch {
    return null;
  } finally {
    clearTimeout(timeout);
  }
}

export async function generateAgentResponse(request: AgentRequest): Promise<AgentResponse> {
  const message = clean(request.message || "");
  const records = retrieveExperienceRecords(request.mode, message, request.payload ?? {}, 5);
  const fallback = responseForMode({ ...request, message }, records);
  const groq = await tryGroqResponse({ ...request, message }, records, fallback);
  return groq ?? fallback;
}
