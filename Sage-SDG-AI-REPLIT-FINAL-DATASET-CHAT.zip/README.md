# Sage SDG AI

**Tagline:** Your human-like guide for learning, well-being, and clean water action.

Sage SDG AI is a Next.js/Replit-ready SDG assistant with three modes:

- **Learn Mode — SDG 4:** explanations, study plans, quizzes, and progress tracking.
- **MindCare Mode — SDG 3:** safe reflection, breathing support, burnout/stress guidance, and emergency escalation.
- **AquaLife Mode — SDG 6 + SDG 3:** water pollution awareness, symptoms/risk communication, reporting workflow, and country-level clean-water action planning.

## What is improved in this build

This version includes a built-in **experience-style SDG dataset** and a more conversational agent brain. The app no longer only returns a static card. It chats using dataset matches, explains SDG basics, discusses country-level water pollution fixes, and supports safe mental well-being reflection.

## Run on Replit

Click **Run**. The `.replit` file runs:

```bash
npm install && npm run dev -- -H 0.0.0.0 -p 3000
```

## Deploy on Replit

Build command:

```bash
npm install && npm run build
```

Run command:

```bash
npm run start -- -H 0.0.0.0 -p 3000
```

Port: `3000`

## Optional AI/API keys

The app works without keys. For more natural AI chat, add this in Replit Secrets:

```text
GROQ_API_KEY=your_key
GROQ_MODEL=llama-3.1-8b-instant
```

For real database storage, add Supabase keys and run `supabase/schema.sql` in your Supabase SQL Editor.

## Dataset files

- `data/sdg_experience_dataset.json`
- `data/kaggle_dataset_manifest.json`
- `data/water_quality_seed_sample.csv`
- `data/mental_wellbeing_seed_sample.csv`
- `data/learning_progress_seed_sample.csv`

Kaggle datasets usually require credentials and license checks, so this project ships with a safe local dataset plus a Kaggle-ready manifest.
