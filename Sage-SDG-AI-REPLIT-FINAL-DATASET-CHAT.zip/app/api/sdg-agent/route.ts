import { NextResponse } from "next/server";
import { generateAgentResponse } from "@/lib/agent";
import { getSupabaseAdmin } from "@/lib/supabase-admin";
import type { AgentRequest, AgentResponse } from "@/lib/types";

export const dynamic = "force-dynamic";

function isValidMode(mode: unknown): mode is AgentRequest["mode"] {
  return mode === "learn" || mode === "mindcare" || mode === "water";
}

async function saveInteraction(request: AgentRequest, response: AgentResponse) {
  const supabase = getSupabaseAdmin();
  if (!supabase) {
    return { saved: false, reason: "Supabase environment variables are not configured. The app is running in demo/storage-off mode." };
  }

  const userId = request.userId || "demo-user";

  const { error: interactionError } = await supabase.from("interactions").insert({
    user_id: userId,
    mode: request.mode,
    message: request.message,
    response_title: response.title,
    response_summary: response.summary,
    safety_level: response.safetyLevel,
    payload: request.payload ?? {},
    response_payload: response
  });

  if (interactionError) {
    return { saved: false, reason: interactionError.message };
  }

  if (request.mode === "learn") {
    await supabase.from("learn_progress").insert({
      user_id: userId,
      topic: request.message.slice(0, 160) || "General learning",
      progress_delta: Number(response.data?.progressDelta ?? 5),
      skill: String(response.data?.skill ?? "learning")
    });
  }

  if (request.mode === "mindcare") {
    await supabase.from("mindcare_reflections").insert({
      user_id: userId,
      reflection: request.message.slice(0, 1500),
      safety_level: response.safetyLevel
    });
  }

  if (request.mode === "water") {
    await supabase.from("water_reports").insert({
      user_id: userId,
      location: String(request.payload?.location ?? "Unknown"),
      category: String(request.payload?.category ?? "water quality concern"),
      symptoms: String(request.payload?.symptoms ?? request.message),
      people_affected: String(request.payload?.peopleAffected ?? "Unknown"),
      urgency: String(response.data?.urgency ?? response.safetyLevel),
      raw_payload: request.payload ?? {}
    });
  }

  return { saved: true };
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Partial<AgentRequest>;

    if (!isValidMode(body.mode)) {
      return NextResponse.json(
        {
          ok: false,
          error: "Invalid mode. Use learn, mindcare, or water."
        },
        { status: 400 }
      );
    }

    const request: AgentRequest = {
      mode: body.mode,
      message: String(body.message ?? ""),
      userId: body.userId || "demo-user",
      payload: body.payload ?? {}
    };

    const response = await generateAgentResponse(request);
    const database = await saveInteraction(request, response);

    return NextResponse.json({
      ok: true,
      data: response,
      database
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: error instanceof Error ? error.message : "Unexpected server error."
      },
      { status: 500 }
    );
  }
}
