# Sage SDG AI Data Layer

This build includes an internal dataset-style knowledge base in `lib/knowledge.ts`.

It covers:

- SDG 4 education support: active recall, study plans, quizzes, SDG literacy
- SDG 3 mental well-being: stress, burnout, safe reflection, grounding, escalation
- SDG 6 + SDG 3 AquaLife: microbial water risk, chemical/industrial contamination, household safety, country-level clean-water action planning

The app retrieves matching records before generating every answer. If `GROQ_API_KEY` is added in Replit Secrets, Sage uses Groq with the retrieved dataset context. If no key is present, Sage uses the local dataset fallback so the project remains deployable for presentation.

For real Kaggle integration later, replace or expand the records in `lib/knowledge.ts` after cleaning the CSV files into structured records with fields like topic, keywords, evidence, guidance, actions, and escalation.
