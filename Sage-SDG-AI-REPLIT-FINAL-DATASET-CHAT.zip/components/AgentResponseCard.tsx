import { AlertTriangle, CheckCircle2, Database, ShieldAlert } from "lucide-react";
import type { AgentResponse } from "@/lib/types";

type Props = {
  response: AgentResponse | null;
  loading: boolean;
};

type DatasetMatch = {
  id?: string;
  topic?: string;
  sdg?: string;
  source?: string;
};

function SafetyIcon({ level }: { level: AgentResponse["safetyLevel"] }) {
  if (level === "emergency" || level === "high") return <ShieldAlert className="text-rose-200" />;
  if (level === "medium") return <AlertTriangle className="text-orange-200" />;
  return <CheckCircle2 className="text-emerald-200" />;
}

function getDatasetMatches(response: AgentResponse) {
  const matches = response.data?.datasetMatches;
  return Array.isArray(matches) ? (matches as DatasetMatch[]).slice(0, 3) : [];
}

export function AgentResponseCard({ response, loading }: Props) {
  if (loading) {
    return (
      <div className="safe-card rounded-3xl p-6">
        <div className="h-5 w-44 animate-pulse rounded-full bg-white/20" />
        <div className="mt-5 space-y-3">
          <div className="h-4 animate-pulse rounded bg-white/10" />
          <div className="h-4 w-4/5 animate-pulse rounded bg-white/10" />
          <div className="h-4 w-2/3 animate-pulse rounded bg-white/10" />
        </div>
      </div>
    );
  }

  if (!response) {
    return (
      <div className="safe-card rounded-3xl p-6">
        <h3 className="text-xl font-bold text-white">Sage is ready</h3>
        <p className="mt-3 text-sm leading-6 text-orange-50/75">
          Select a mode, type a message, and the answer will come through the single API route: <code>/api/sdg-agent</code>.
        </p>
      </div>
    );
  }

  const datasetMatches = getDatasetMatches(response);

  return (
    <div className="safe-card rounded-3xl p-6">
      <div className="flex items-start gap-3">
        <div className="rounded-2xl bg-white/10 p-3">
          <SafetyIcon level={response.safetyLevel} />
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.25em] text-rose-200">{response.mode} response</p>
          <h3 className="mt-1 text-2xl font-bold text-white">{response.title}</h3>
        </div>
      </div>

      {response.chatText ? (
        <div className="mt-5 whitespace-pre-line rounded-2xl border border-white/10 bg-black/25 p-4 leading-7 text-orange-50/85">{response.chatText}</div>
      ) : (
        <p className="mt-5 leading-7 text-orange-50/85">{response.summary}</p>
      )}

      {response.disclaimer ? (
        <div className="mt-5 rounded-2xl border border-orange-300/25 bg-orange-400/10 p-4 text-sm leading-6 text-orange-100">
          <strong>Safety note:</strong> {response.disclaimer}
        </div>
      ) : null}

      {datasetMatches.length ? (
        <div className="mt-5 rounded-2xl border border-white/10 bg-black/25 p-4 text-sm text-orange-50/80">
          <div className="mb-3 flex items-center gap-2 font-semibold text-white">
            <Database size={16} /> Dataset context used
          </div>
          <div className="grid gap-2 md:grid-cols-3">
            {datasetMatches.map((match) => (
              <div key={match.id ?? match.topic} className="rounded-2xl bg-white/5 p-3">
                <p className="font-semibold text-orange-100">{match.topic}</p>
                <p className="mt-1 text-xs text-orange-50/60">{match.sdg}</p>
              </div>
            ))}
          </div>
          {response.datasetInsights?.length ? (
            <div className="mt-4 border-t border-white/10 pt-4">
              <p className="mb-2 font-semibold text-white">Experience-dataset insights</p>
              <ul className="space-y-2">
                {response.datasetInsights.map((insight) => (
                  <li key={insight} className="rounded-2xl bg-white/5 p-3">{insight}</li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div>
          <h4 className="font-semibold text-white">Recommended actions</h4>
          <ul className="mt-3 space-y-2 text-sm leading-6 text-orange-50/80">
            {response.actions.map((action) => (
              <li key={action} className="flex gap-2">
                <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-rose-300" />
                <span>{action}</span>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="font-semibold text-white">Follow-up questions</h4>
          <ul className="mt-3 space-y-2 text-sm leading-6 text-orange-50/80">
            {response.followUpQuestions.map((question) => (
              <li key={question} className="rounded-2xl bg-white/5 p-3">{question}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
