import type { AgentRequest, AgentResponse, SdgMode } from "@/lib/types";

const severeDistressKeywords = [
  "suicide",
  "kill myself",
  "self harm",
  "hurt myself",
  "end my life",
  "can't live",
  "want to die"
];

const dangerWaterKeywords = [
  "vomiting blood",
  "bloody diarrhea",
  "severe dehydration",
  "unconscious",
  "blue lips",
  "can't breathe",
  "seizure",
  "infant",
  "pregnant"
];

function includesAny(text: string, keywords: string[]) {
  const lower = text.toLowerCase();
  return keywords.some((keyword) => lower.includes(keyword));
}

function cleanMessage(message: string) {
  return message.trim().slice(0, 2000);
}

function learnResponse(request: AgentRequest): AgentResponse {
  const topic = cleanMessage(request.message) || "your selected topic";
  const wantsQuiz = /quiz|test|mcq|question/i.test(topic);
  const wantsPlan = /plan|schedule|study/i.test(topic);

  if (wantsQuiz) {
    return {
      mode: "learn",
      title: "Learn Mode: Quick Quiz",
      summary: `Here is a short active-recall quiz for: ${topic}`,
      safetyLevel: "low",
      actions: [
        "Q1: Explain the idea in one simple sentence.",
        "Q2: Give one real-life example.",
        "Q3: What mistake do beginners usually make here?",
        "Q4: Write one exam-style answer in 5 lines."
      ],
      followUpQuestions: [
        "Do you want easier questions or exam-level questions?",
        "Should I turn this into MCQs?"
      ],
      data: {
        progressDelta: 10,
        skill: "active recall"
      }
    };
  }

  if (wantsPlan) {
    return {
      mode: "learn",
      title: "Learn Mode: Study Plan",
      summary: `A practical study plan for: ${topic}`,
      safetyLevel: "low",
      actions: [
        "Spend 15 minutes understanding the core concept.",
        "Spend 20 minutes writing notes in your own words.",
        "Spend 15 minutes solving questions without looking at notes.",
        "End with a 5-minute self-test and mark weak points."
      ],
      followUpQuestions: [
        "How many days do you have before the test?",
        "Do you want a one-day crash plan?"
      ],
      data: {
        progressDelta: 15,
        skill: "study planning"
      }
    };
  }

  return {
    mode: "learn",
    title: "Learn Mode: Simple Explanation",
    summary: `Let's break down ${topic} in a clear way: start with the basic definition, then understand why it matters, then apply it to one example. Learning sticks when you explain it back in your own words, not when you only reread.` ,
    safetyLevel: "low",
    actions: [
      "Write the topic title at the top of your notes.",
      "Define it in one sentence.",
      "Add one example from real life or your course.",
      "Test yourself by explaining it without looking."
    ],
    followUpQuestions: [
      "Should I explain this like a beginner or exam answer?",
      "Do you want a quiz on this topic?"
    ],
    data: {
      progressDelta: 8,
      skill: "concept clarity"
    }
  };
}

function mindcareResponse(request: AgentRequest): AgentResponse {
  const message = cleanMessage(request.message);

  if (includesAny(message, severeDistressKeywords)) {
    return {
      mode: "mindcare",
      title: "MindCare Mode: Immediate Support Needed",
      summary: "I am really sorry you are feeling this much pain. Your safety matters more than any app response right now.",
      disclaimer: "This platform cannot diagnose, treat, or replace professional mental-health care. If you may harm yourself or someone else, contact local emergency services immediately or reach a trusted person near you right now.",
      safetyLevel: "emergency",
      actions: [
        "Move away from anything you could use to hurt yourself.",
        "Call emergency services or a local crisis helpline immediately.",
        "Message or call one trusted person and say: I am not safe alone right now.",
        "Stay in a public or shared space until help arrives."
      ],
      followUpQuestions: [
        "Are you in immediate physical danger right now?",
        "Is there someone near you who can stay with you?"
      ]
    };
  }

  return {
    mode: "mindcare",
    title: "MindCare Mode: Safe Reflection",
    summary: "Pause for a moment. You do not need to solve your whole life in one sitting. We can lower the pressure first, then decide the next small step.",
    disclaimer: "MindCare provides general well-being support only. It does not diagnose conditions, prescribe treatment, or replace professional care.",
    safetyLevel: "medium",
    actions: [
      "Try 4-4-6 breathing: inhale 4 seconds, hold 4 seconds, exhale 6 seconds. Repeat 4 times.",
      "Name three things you can see, two things you can hear, and one thing you can feel.",
      "Write one sentence: The main thing bothering me right now is...",
      "Choose one tiny next action that takes less than 5 minutes."
    ],
    followUpQuestions: [
      "Do you want a breathing exercise or reflection prompt?",
      "Is this stress about study, work, family, or health?"
    ],
    data: {
      exercise: "4-4-6 breathing",
      recommendedDurationMinutes: 3
    }
  };
}

function waterResponse(request: AgentRequest): AgentResponse {
  const message = cleanMessage(request.message);
  const payload = request.payload ?? {};
  const location = String(payload.location ?? "your area");
  const category = String(payload.category ?? "water quality concern");
  const affected = String(payload.peopleAffected ?? "unknown number of people");
  const symptoms = String(payload.symptoms ?? message);
  const combined = `${message} ${symptoms} ${category}`;

  if (includesAny(combined, dangerWaterKeywords)) {
    return {
      mode: "water",
      title: "AquaLife Mode: Urgent Water Safety Alert",
      summary: `The report from ${location} mentions potentially serious symptoms or vulnerable people. Treat this as urgent and avoid unsafe water exposure until the issue is checked.` ,
      disclaimer: "AquaLife provides informational water-risk guidance only. It does not diagnose illness or replace medical/public-health advice. Severe symptoms need urgent professional help.",
      safetyLevel: "emergency",
      actions: [
        "Seek urgent medical care for severe symptoms, infants, pregnant people, elderly people, or dehydration signs.",
        "Stop using the suspected water for drinking, cooking, brushing teeth, or preparing baby formula.",
        "Use sealed bottled water or properly boiled/cooled water if safe guidance allows boiling.",
        "Report the issue to the local water authority, municipal office, school/clinic administration, or community health worker.",
        "Record location, smell/color/taste, number affected, and when symptoms started."
      ],
      followUpQuestions: [
        "What is the exact location or nearest landmark?",
        "How many people are affected and what are their ages?"
      ],
      data: {
        location,
        category,
        peopleAffected: affected,
        urgency: "emergency"
      }
    };
  }

  const isCloudy = /cloudy|dirty|muddy|brown|yellow|particles/i.test(combined);
  const isSmelly = /smell|odor|sewer|chemical|chlorine|rotten/i.test(combined);
  const urgency = isCloudy || isSmelly ? "medium" : "low";

  return {
    mode: "water",
    title: "AquaLife Mode: Water Risk Guidance",
    summary: `For ${location}, this looks like a ${urgency}-urgency ${category}. The smart move is to reduce exposure, document the issue, and report it clearly without panic.` ,
    disclaimer: "AquaLife is for awareness and reporting guidance only. It does not confirm contamination, diagnose illness, or replace medical/public-health testing.",
    safetyLevel: urgency,
    actions: [
      "Do not drink water that looks, smells, or tastes unusual until it is checked.",
      "Use a safer alternative source for drinking and cooking if available.",
      "Take a photo/video of the issue if safe to do so.",
      "Report the issue with location, date/time, water source, visible signs, and people affected.",
      "If diarrhea, fever, vomiting, dehydration, or worsening symptoms occur, seek medical advice quickly."
    ],
    followUpQuestions: [
      "Is the water from a tap, hand pump, tanker, filter plant, or well?",
      "Are children, elderly people, or pregnant people affected?"
    ],
    data: {
      location,
      category,
      peopleAffected: affected,
      urgency
    }
  };
}

export function generateAgentResponse(request: AgentRequest): AgentResponse {
  const mode: SdgMode = request.mode;

  if (mode === "learn") return learnResponse(request);
  if (mode === "mindcare") return mindcareResponse(request);
  if (mode === "water") return waterResponse(request);

  return {
    mode: "learn",
    title: "Sage SDG AI",
    summary: "Please select a valid mode: learn, mindcare, or water.",
    safetyLevel: "low",
    actions: ["Choose one mode and send a clear question."],
    followUpQuestions: ["Which mode do you want to use?"],
    data: {}
  };
}
