export type SdgMode = "learn" | "mindcare" | "water";

export type AgentRequest = {
  mode: SdgMode;
  message: string;
  userId?: string;
  payload?: Record<string, unknown>;
};

export type AgentResponse = {
  mode: SdgMode;
  title: string;
  summary: string;
  disclaimer?: string;
  safetyLevel: "low" | "medium" | "high" | "emergency";
  actions: string[];
  followUpQuestions: string[];
  data?: Record<string, unknown>;
};

export type DashboardMetrics = {
  totalInteractions: number;
  learnSessions: number;
  mindcareSessions: number;
  waterReports: number;
  weeklyActivity: Array<{ day: string; interactions: number }>;
  modeBreakdown: Array<{ name: string; value: number }>;
};
