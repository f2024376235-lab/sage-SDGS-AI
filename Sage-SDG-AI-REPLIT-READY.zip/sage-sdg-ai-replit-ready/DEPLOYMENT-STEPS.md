# Fast Deployment Steps

1. Upload this project to GitHub exactly as it is.
2. Confirm `package.json` is visible in the GitHub repo root.
3. Go to Vercel and import the GitHub repo.
4. Fill settings:

```txt
Framework Preset: Next.js
Root Directory: ./
Build Command: npm run build
Output Directory: leave empty
Install Command: npm install
Environment Variables: empty for first deploy
```

5. Click Deploy.
6. Open the live Vercel URL.
7. Test `/`, `/dashboard`, and the agent form.

## If deployment fails

### Error: package.json not found
Your GitHub repo structure is wrong. `package.json` must be in the first/root screen of the repo.

### Error: Output Directory public
Remove output directory. It must be blank for Next.js.

### Error: Supabase env missing
That should not fail this build. Supabase is optional in this version.

### Error: npm install failed
Delete uploaded `node_modules` from GitHub and redeploy.
