# Sage SDG AI

**Tagline:** Your human-like guide for learning, well-being, and clean water action.

This is a Vercel-ready Next.js project for a three-mode SDG assistant:

- **Learn Mode / SDG 4:** explanations, study plans, quizzes, progress tracking logic
- **MindCare Mode / SDG 3:** safe reflection prompts, breathing exercises, self-care support
- **AquaLife Mode / SDG 6 + SDG 3:** water-risk awareness, urgency guidance, reporting steps

The app is designed to deploy online on Vercel. It is not a localhost-only project.

## What is included

- Next.js App Router
- React + TypeScript
- Tailwind CSS premium red/black/gradient UI
- Recharts dashboard
- Lucide icons
- Single API endpoint: `/api/sdg-agent`
- Supabase-ready backend logging
- Supabase SQL schema
- Safe fallback mode when Supabase env variables are not added

## Vercel Settings

Use these exactly:

```txt
Framework Preset: Next.js
Root Directory: ./
Build Command: npm run build
Output Directory: leave empty
Install Command: npm install
Environment Variables: optional for first deployment
```

Do **not** upload `node_modules`.

## Supabase Setup

1. Create a Supabase project.
2. Open Supabase SQL Editor.
3. Paste `supabase/schema.sql` and run it.
4. In Vercel, add these environment variables:

```txt
NEXT_PUBLIC_SUPABASE_URL=your Supabase project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=your anon key
SUPABASE_SERVICE_ROLE_KEY=your service role key
```

5. Redeploy Vercel.

The app deploys without Supabase, but database storage activates only after these values are added.

## API Contract

POST `/api/sdg-agent`

```json
{
  "mode": "learn",
  "message": "Explain photosynthesis and make a quiz",
  "userId": "demo-user",
  "payload": {}
}
```

Modes:

```txt
learn
mindcare
water
```

Water mode may include:

```json
{
  "mode": "water",
  "message": "Water is brown and smells bad",
  "payload": {
    "location": "Area name",
    "category": "dirty or cloudy water",
    "peopleAffected": "5 families",
    "symptoms": "stomach pain and diarrhea"
  }
}
```

## Safety Rules

- No medical diagnosis
- No prescriptions
- No academic dishonesty
- Emergency escalation for severe distress or dangerous symptoms
- MindCare and AquaLife include clear disclaimers

## Presentation Checklist

After deployment, take screenshots of:

1. Homepage
2. Learn Mode response
3. MindCare Mode response
4. AquaLife Mode form and response
5. Dashboard page
6. Supabase tables if connected
7. Vercel deployment success page
