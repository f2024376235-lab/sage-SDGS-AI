"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Brain, Droplets, GraduationCap, Send, ShieldCheck, Sparkles } from "lucide-react";
import { AgentResponseCard } from "@/components/AgentResponseCard";
import { ModeCard } from "@/components/ModeCard";
import { WaterReportForm } from "@/components/WaterReportForm";
import type { AgentResponse, SdgMode } from "@/lib/types";

const modes = [
  {
    mode: "learn" as const,
    title: "Learn Mode",
    sdg: "SDG 4",
    description: "Clear explanations, study plans, quizzes, and progress-building guidance.",
    icon: GraduationCap
  },
  {
    mode: "mindcare" as const,
    title: "MindCare Mode",
    sdg: "SDG 3",
    description: "Safe reflection prompts, breathing exercises, and general self-care support.",
    icon: Brain
  },
  {
    mode: "water" as const,
    title: "AquaLife Mode",
    sdg: "SDG 6 + SDG 3",
    description: "Water-risk awareness, symptom urgency guidance, and reporting steps.",
    icon: Droplets
  }
];

const placeholders: Record<SdgMode, string> = {
  learn: "Example: Explain photosynthesis and make a 1-day study plan.",
  mindcare: "Example: I feel stressed about my presentation. Help me calm down safely.",
  water: "Example: The tap water is brown and smells bad. What should we do?"
};

export default function HomePage() {
  const [mode, setMode] = useState<SdgMode>("learn");
  const [message, setMessage] = useState("");
  const [payload, setPayload] = useState<Record<string, string>>({});
  const [response, setResponse] = useState<AgentResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const selectedMode = useMemo(() => modes.find((item) => item.mode === mode), [mode]);

  async function sendMessage() {
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/sdg-agent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          mode,
          message,
          userId: "demo-user",
          payload
        })
      });

      const data = await res.json();

      if (!data.ok) {
        throw new Error(data.error || "Request failed.");
      }

      setResponse(data.data);
      setMessage("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen px-5 py-8 text-orange-50 md:px-8">
      <section className="mx-auto max-w-7xl">
        <nav className="mb-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="rounded-2xl bg-rose-500/25 p-3 text-rose-100 shadow-glow">
              <Sparkles size={28} />
            </div>
            <div>
              <p className="text-xl font-black tracking-tight text-white">Sage SDG AI</p>
              <p className="text-xs text-orange-100/70">Your human-like guide for learning, well-being, and clean water action.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="rounded-full border border-white/15 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10">
              Dashboard
            </Link>
            <a href="#agent" className="rounded-full bg-rose-500 px-4 py-2 text-sm font-bold text-white hover:bg-rose-400">
              Open Agent
            </a>
          </div>
        </nav>

        <div className="grid items-center gap-8 lg:grid-cols-[1.1fr_.9fr]">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-rose-300/25 bg-rose-500/10 px-4 py-2 text-sm text-rose-100">
              <ShieldCheck size={16} /> Safety-first multi-mode assistant
            </div>
            <h1 className="max-w-4xl text-4xl font-black leading-tight text-white md:text-6xl">
              Learning, calm reflection, and water action in one deployable SDG platform.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-orange-50/80">
              Sage SDG AI routes every request through <code className="rounded bg-black/40 px-2 py-1">/api/sdg-agent</code>, gives structured responses by active mode, and stores activity in Supabase when credentials are connected.
            </p>
            <div className="mt-6 grid gap-3 text-sm text-orange-50/75 md:grid-cols-3">
              <div className="light-balance rounded-2xl p-4">No medical diagnosis or prescriptions.</div>
              <div className="light-balance rounded-2xl p-4">No academic dishonesty support.</div>
              <div className="light-balance rounded-2xl p-4">Emergency escalation for severe distress or dangerous symptoms.</div>
            </div>
          </div>

          <div className="safe-card rounded-[2rem] p-6 shadow-glow">
            <p className="text-sm uppercase tracking-[0.3em] text-rose-200">Presentation-ready</p>
            <h2 className="mt-3 text-2xl font-bold text-white">What this build includes</h2>
            <ul className="mt-5 space-y-3 text-sm leading-6 text-orange-50/80">
              <li>✓ Next.js + React + TypeScript + Tailwind UI</li>
              <li>✓ Learn, MindCare, and AquaLife workflows</li>
              <li>✓ Supabase schema and optional backend logging</li>
              <li>✓ Dashboard with Recharts visualizations</li>
              <li>✓ Vercel-ready root structure with package.json at root</li>
            </ul>
          </div>
        </div>

        <section id="agent" className="mt-14 grid gap-6 lg:grid-cols-[.85fr_1.15fr]">
          <div className="space-y-4">
            <h2 className="text-3xl font-black text-white">Choose a mode</h2>
            {modes.map((item) => (
              <ModeCard key={item.mode} {...item} active={mode === item.mode} onClick={setMode} />
            ))}
          </div>

          <div className="space-y-5">
            <div className="safe-card rounded-3xl p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-[0.25em] text-rose-200">Active mode</p>
                  <h2 className="text-2xl font-bold text-white">{selectedMode?.title}</h2>
                </div>
                <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-orange-100">POST /api/sdg-agent</span>
              </div>

              <WaterReportForm activeMode={mode} payload={payload} setPayload={setPayload} />

              <textarea
                className="mt-4 min-h-36 w-full rounded-3xl border border-white/10 bg-black/35 p-4 text-white outline-none ring-rose-400/40 placeholder:text-orange-50/40 focus:ring-2"
                placeholder={placeholders[mode]}
                value={message}
                onChange={(event) => setMessage(event.target.value)}
              />

              {error ? <p className="mt-3 rounded-2xl bg-rose-500/15 p-3 text-sm text-rose-100">{error}</p> : null}

              <button
                type="button"
                onClick={sendMessage}
                disabled={loading}
                className="mt-4 inline-flex items-center gap-2 rounded-full bg-rose-500 px-6 py-3 font-bold text-white transition hover:bg-rose-400 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Send size={18} /> {loading ? "Thinking..." : "Send to Sage"}
              </button>
            </div>

            <AgentResponseCard response={response} loading={loading} />
          </div>
        </section>
      </section>
    </main>
  );
}
