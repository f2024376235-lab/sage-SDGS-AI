import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sage SDG AI",
  description: "Your human-like guide for learning, well-being, and clean water action."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
