# Dataset Notes

This folder contains clean seed datasets for presentation and safe fallback behavior.

For final research-grade work, replace these JSON files with cleaned Kaggle exports related to:

- Education progress / learning outcomes
- Mental well-being awareness or support resources
- Water quality, sanitation, contamination, or public-health risk indicators

Keep columns simple and do not upload private health or identity data. The deployed app works even without external datasets because the agent API has safe built-in logic.
