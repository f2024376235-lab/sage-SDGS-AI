"use client";

import type { SdgMode } from "@/lib/types";

type Props = {
  activeMode: SdgMode;
  payload: Record<string, string>;
  setPayload: (payload: Record<string, string>) => void;
};

export function WaterReportForm({ activeMode, payload, setPayload }: Props) {
  if (activeMode !== "water") return null;

  const update = (key: string, value: string) => {
    setPayload({ ...payload, [key]: value });
  };

  return (
    <div className="grid gap-3 md:grid-cols-2">
      <input
        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none ring-rose-400/40 placeholder:text-orange-50/40 focus:ring-2"
        placeholder="Location / area / landmark"
        value={payload.location ?? ""}
        onChange={(event) => update("location", event.target.value)}
      />
      <select
        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none ring-rose-400/40 focus:ring-2"
        value={payload.category ?? "water quality concern"}
        onChange={(event) => update("category", event.target.value)}
      >
        <option value="water quality concern">Water quality concern</option>
        <option value="dirty or cloudy water">Dirty or cloudy water</option>
        <option value="bad smell or chemical odor">Bad smell or chemical odor</option>
        <option value="possible waterborne illness symptoms">Possible waterborne illness symptoms</option>
        <option value="broken pipe or sewage mixing">Broken pipe or sewage mixing</option>
      </select>
      <input
        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none ring-rose-400/40 placeholder:text-orange-50/40 focus:ring-2"
        placeholder="People affected, e.g., 5 families / school students"
        value={payload.peopleAffected ?? ""}
        onChange={(event) => update("peopleAffected", event.target.value)}
      />
      <input
        className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-white outline-none ring-rose-400/40 placeholder:text-orange-50/40 focus:ring-2"
        placeholder="Symptoms or visible signs"
        value={payload.symptoms ?? ""}
        onChange={(event) => update("symptoms", event.target.value)}
      />
    </div>
  );
}
