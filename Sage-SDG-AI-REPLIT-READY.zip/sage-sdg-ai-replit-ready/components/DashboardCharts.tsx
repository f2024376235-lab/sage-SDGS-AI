"use client";

import { useEffect, useState } from "react";
import { BarChart, Bar, ResponsiveContainer, XAxis, YAxis, Tooltip, PieChart, Pie, Cell } from "recharts";
import type { DashboardMetrics } from "@/lib/types";

const fallback: DashboardMetrics = {
  totalInteractions: 0,
  learnSessions: 0,
  mindcareSessions: 0,
  waterReports: 0,
  weeklyActivity: [],
  modeBreakdown: []
};

const cells = ["#e11d48", "#f59e0b", "#14b8a6"];

export function DashboardCharts() {
  const [metrics, setMetrics] = useState<DashboardMetrics>(fallback);
  const [source, setSource] = useState("loading");

  useEffect(() => {
    async function load() {
      const response = await fetch("/api/dashboard");
      const data = await response.json();
      setMetrics(data.data);
      setSource(data.source);
    }

    load().catch(() => setSource("demo"));
  }, []);

  const stats = [
    { label: "Total interactions", value: metrics.totalInteractions },
    { label: "Learn sessions", value: metrics.learnSessions },
    { label: "MindCare sessions", value: metrics.mindcareSessions },
    { label: "Water reports", value: metrics.waterReports }
  ];

  return (
    <div className="space-y-8">
      <div className="grid gap-4 md:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="safe-card rounded-3xl p-5">
            <p className="text-xs uppercase tracking-[0.2em] text-orange-100/60">{stat.label}</p>
            <p className="mt-2 text-3xl font-black text-white">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="safe-card rounded-3xl p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h3 className="text-xl font-bold text-white">Weekly activity</h3>
            <span className="rounded-full bg-white/10 px-3 py-1 text-xs text-orange-100">{source} data</span>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={metrics.weeklyActivity}>
                <XAxis dataKey="day" stroke="#fed7aa" />
                <YAxis stroke="#fed7aa" />
                <Tooltip contentStyle={{ background: "#111116", border: "1px solid rgba(255,255,255,.15)", borderRadius: "16px" }} />
                <Bar dataKey="interactions" radius={[12, 12, 0, 0]} fill="#e11d48" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="safe-card rounded-3xl p-6">
          <h3 className="mb-4 text-xl font-bold text-white">Mode breakdown</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={metrics.modeBreakdown} dataKey="value" nameKey="name" outerRadius={95} label>
                  {metrics.modeBreakdown.map((entry, index) => (
                    <Cell key={entry.name} fill={cells[index % cells.length]} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ background: "#111116", border: "1px solid rgba(255,255,255,.15)", borderRadius: "16px" }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
