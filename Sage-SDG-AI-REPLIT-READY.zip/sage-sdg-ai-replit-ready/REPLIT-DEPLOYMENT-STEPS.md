# Sage SDG AI — Replit Deployment Steps

## 1. Import or upload the project
Upload all files to Replit so `package.json` is visible in the root file list.

Your root should look like:

```text
package.json
.replit
replit.nix
app/
components/
lib/
data/
supabase/
```

## 2. Run inside Replit editor
Click **Run**. The `.replit` file runs:

```bash
npm install && npm run dev -- -H 0.0.0.0 -p 3000
```

Open the web preview. Test Learn, MindCare, AquaLife, dashboard, and `/api/sdg-agent`.

## 3. Deploy online
Open **Deployments** in Replit and choose a web/server deployment such as Autoscale/Cloud Run.

Use these commands if Replit asks manually:

```bash
Build command: npm install && npm run build
Run command: npm run start -- -H 0.0.0.0 -p 3000
Port: 3000
```

After deployment, Replit gives you a public URL. Share that link for presentation.

## 4. Supabase later
The app works in demo mode without Supabase keys. For real database storage, create a Supabase project and run:

```text
supabase/schema.sql
```

Then add secrets in Replit:

```text
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY
```

## 5. Do not upload node_modules
Replit installs packages from `package.json`. Uploading `node_modules` causes size and dependency problems.
